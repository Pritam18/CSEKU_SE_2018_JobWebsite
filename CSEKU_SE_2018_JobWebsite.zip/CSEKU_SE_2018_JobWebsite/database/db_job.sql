-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2018 at 08:20 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_job`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `adminId` int(40) NOT NULL,
  `adminName` varchar(100) NOT NULL,
  `categoryId` int(40) NOT NULL,
  `companyId` int(40) NOT NULL,
  `adminUserName` varchar(100) NOT NULL,
  `adminEmail` varchar(255) NOT NULL,
  `adminPass` varchar(255) NOT NULL,
  `level` int(12) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`adminId`, `adminName`, `categoryId`, `companyId`, `adminUserName`, `adminEmail`, `adminPass`, `level`) VALUES
(1, 'Pritam Khan', 0, 0, 'Pritam', 'piru@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 0),
(10, 'Rayhan', 1, 2, 'Rayhan', 'rayhan@gmail.com', '1b03f071de953187082e8407bf3d0c70', 1),
(9, 'Biswajit', 1, 3, 'Biswajit', 'biswajit@gmail.com', '3bf33ce89bf20547e350eecf0c1be141', 1),
(8, 'Chayan', 4, 4, 'Chayan', 'chayan@gmail.com', 'cc066c58be86e08ffbc438bd840e416c', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_application`
--

CREATE TABLE `tbl_application` (
  `regiid` int(11) NOT NULL,
  `appplicantid` int(50) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `faname` varchar(255) NOT NULL,
  `moname` varchar(255) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `religion` varchar(10) NOT NULL,
  `marital_status` varchar(12) NOT NULL,
  `nationality` varchar(20) NOT NULL,
  `nationalid` varchar(20) NOT NULL,
  `presentaddress` text NOT NULL,
  `permanentaddress` text NOT NULL,
  `email` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_application`
--

INSERT INTO `tbl_application` (`regiid`, `appplicantid`, `fname`, `lname`, `faname`, `moname`, `gender`, `religion`, `marital_status`, `nationality`, `nationalid`, `presentaddress`, `permanentaddress`, `email`) VALUES
(3, 1, 'pritom', 'Khan', '', '', '', '', '', 'australia', '', '', '', 'piru@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_apply`
--

CREATE TABLE `tbl_apply` (
  `JobId` int(40) NOT NULL,
  `CompanyId` int(50) NOT NULL,
  `ApplicantId` int(50) NOT NULL,
  `AdminId` int(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_apply`
--

INSERT INTO `tbl_apply` (`JobId`, `CompanyId`, `ApplicantId`, `AdminId`) VALUES
(4, 4, 1, 5),
(5, 4, 1, 5),
(4, 4, 1, 5),
(4, 4, 1, 5),
(4, 4, 1, 5),
(4, 4, 1, 5),
(1, 3, 1, 4),
(1, 3, 1, 4),
(4, 4, 1, 5),
(4, 4, 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `catId` int(40) NOT NULL,
  `catName` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`catId`, `catName`) VALUES
(1, 'Bank'),
(4, 'Software Company'),
(5, 'NGO'),
(6, 'Polytechnical Institute');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_company`
--

CREATE TABLE `tbl_company` (
  `companyId` int(40) NOT NULL,
  `categoryId` int(40) NOT NULL,
  `companyName` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_company`
--

INSERT INTO `tbl_company` (`companyId`, `categoryId`, `companyName`) VALUES
(3, 1, 'City Bank'),
(2, 1, 'BRAC BANK'),
(4, 4, 'Systway');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_companydetails`
--

CREATE TABLE `tbl_companydetails` (
  `jobid` int(11) NOT NULL,
  `adminId` int(40) NOT NULL,
  `companyId` int(40) NOT NULL,
  `categoryId` int(40) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '0',
  `location` varchar(255) NOT NULL,
  `experience` varchar(20) NOT NULL,
  `salary` int(10) NOT NULL,
  `apost` int(10) NOT NULL,
  `deadline` date NOT NULL,
  `publish` int(11) NOT NULL DEFAULT '4'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_companydetails`
--

INSERT INTO `tbl_companydetails` (`jobid`, `adminId`, `companyId`, `categoryId`, `designation`, `body`, `image`, `type`, `location`, `experience`, `salary`, `apost`, `deadline`, `publish`) VALUES
(8, 8, 4, 4, 'Intern Engineer', 'Great Opportunity for freshers.&nbsp;.....', 'upload/f7f386863f.png', 0, 'Khulna', 'Fresher', 10000, 5, '2018-04-15', 3),
(10, 9, 3, 1, 'Manager', '                            dsrthgfhxhjghmukft.....                        ', 'upload/58dc6468ea.png', 0, 'Dhaka', '5-6 years', 75000, 1, '2018-04-01', 4),
(11, 9, 3, 1, 'Accountant', 'fdgtddzdfvfgrt.....', 'upload/2bd0fbd6d2.png', 0, 'Rangpur', '2years', 40000, 1, '2018-04-30', 3),
(12, 10, 2, 1, 'Accountant', 'fsfehrtyjfgfvdsgrd.....', 'upload/5c9bd72ba8.png', 1, 'Dhaka', 'Fresher', 60000, 1, '2018-04-10', 4),
(13, 10, 2, 1, 'General Manager', 'asfgrhdtcsdtcegf.....', 'upload/ca2e9e1f32.png', 1, 'Rajshahi', '10 years', 100000, 1, '2018-04-30', 3),
(14, 10, 2, 1, 'Assistant General Manager', '                            vdfgtbghtg.....                        ', 'upload/6eb9a8bcbc.png', 0, 'Sylhet', '10 years', 90000, 1, '2018-05-05', 3),
(15, 9, 3, 1, 'Intern officer', 'dgsdrhyergf.....', 'upload/4d1a8f6bb8.png', 0, 'Khulna', 'Fresher', 10000, 2, '2018-05-31', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(100) NOT NULL,
  `FullName` varchar(50) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `FullName`, `Email`, `Password`) VALUES
(1, 'Pritam Khan', 'piru@gmail.com', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `tbl_application`
--
ALTER TABLE `tbl_application`
  ADD PRIMARY KEY (`regiid`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`catId`);

--
-- Indexes for table `tbl_company`
--
ALTER TABLE `tbl_company`
  ADD PRIMARY KEY (`companyId`);

--
-- Indexes for table `tbl_companydetails`
--
ALTER TABLE `tbl_companydetails`
  ADD PRIMARY KEY (`jobid`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `adminId` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tbl_application`
--
ALTER TABLE `tbl_application`
  MODIFY `regiid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `catId` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_company`
--
ALTER TABLE `tbl_company`
  MODIFY `companyId` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbl_companydetails`
--
ALTER TABLE `tbl_companydetails`
  MODIFY `jobid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
