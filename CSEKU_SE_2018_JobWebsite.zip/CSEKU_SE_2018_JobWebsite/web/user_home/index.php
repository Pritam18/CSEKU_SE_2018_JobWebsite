<?php 
include 'classes/jobdetails.php';
?>
<?php 
	include 'lib/Session.php';
	Session::init();
   // include 'lib/Database.php';
	//include 'helpers/Format.php';

	spl_autoload_register(function($class){
		include_once "classes/".$class.".php";
	});

	//$db  = new Database();
	//$fm  = new Format();
	 // $user = new User();
 ?>

<!DOCTYPE HTML>
<head>
<title>Job Website</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/menu.css" rel="stylesheet" type="text/css" media="all"/>
<script src="js/jquerymain.js"></script>
<script src="js/script.js" type="text/javascript"></script>
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script> 
<script type="text/javascript" src="js/nav.js"></script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script> 
<script type="text/javascript" src="js/nav-hover.js"></script>
<link href='http://fonts.googleapis.com/css?family=Monda' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Doppio+One' rel='stylesheet' type='text/css'>
<script type="text/javascript">
  $(document).ready(function($){
    $('#dc_mega-menu-orange').dcMegaMenu({rowItems:'4',speed:'fast',effect:'fade'});
  });
</script>

</head>
<body>
  <div class="wrap">
		<div class="header_top">
			<div class="logo">
				<a href="#"><img style="height:100px;weight:140px" src="images/logo1.png" alt="" /></a>
			</div>
		
			  <div class="header_top_right">
			   
			    
		 <div class="clear"></div>
	 </div>

	 
	 <div class="clear"></div>
	<?php 
	if (isset($_GET['uid'])) {
		Session::destroy();
	}
 ?>
 </div>
<div class="menu">
	<ul id="dc_mega-menu-orange" class="dc_mm-orange">
	  <li><a href="index.php">Home</a></li>
	  
	  <?php 
	  		$login = Session::get("userlogin");
	  		if ($login == true) { ?>
	            <li><a href="profile.php">Profile</a> </li>
	            <li><a href="?uid=<?php Session::get('id')?>">Logout</a></li>
	            <li><a href="alljob.php">JOBS</a> </li>
	            

	  <?php } 
	  		else
	  		{ ?>
	  			 <li><a href="login.php">LOGIN</a></li>
	   <?php 
	  	}
	  ?>
	   
	  
	  <li><a href="contact.php">Contact</a> </li>
	  <div class="clear"></div>
	</ul>
</div>


<?php
    $jobdet = new Jobdetails();
    $fm = new Format();
    
?>

	<div class="header_bottom">
		<div class="header_bottom_left">
			
			<div class="section group" >
			<?php
			    $getcmpde = $jobdet->getallcompanydetails();
			    if($getcmpde)
			    {
			    	while($value=$getcmpde->fetch_assoc())
			    	{
			  ?>
				<div class="listview_1_of_2 images_1_of_2" style="height: 150px">
				
					<div class="listimg listimg_2_of_1">
						 <a href="preview.html"> <img src="admin/<?php echo $value['image'];?>" alt="" /></a>
					</div>

					
				    <div class="text list_2_of_1">
				    	<?php
					    $flag=0;
					    $now=date('Y-m-d');
					    $deadline=$value['deadline'];
					    if(strtotime($now)>strtotime($deadline))
					    {
					    	$flag=1;

					?>
						<h2 style="background: red"><?php echo $value['companyName'];?></h2>
						<?php } else {?>
						<h2 style="background: green"><?php echo $value['companyName'];?></h2>
						<?php } ?>
						<p><?php echo $fm->textShorten($value['body']);?></p>
						<?php
						    if($flag==1)
						    {
						?>
						<h2><?php echo 'Time is up for Applying'?></h2>
						<?php } ?>
						<div class="button"><span><a href="details.php?did=<?php echo $value['jobid'];?>" class="details">Details</a></span></div>
				   </div>

			   </div>
			   <?php } }?>	
			
			</div>
			<div class="section group">

				<?php
			    $getcmpde=$jobdet->getallcompanydetails1();
			    if($getcmpde)
			    {
			    	while($value=$getcmpde->fetch_assoc())
			    	{
			  ?>
				<div class="listview_1_of_2 images_1_of_2" style="height: 150px">
				
					<div class="listimg listimg_2_of_1">
						 <a href="preview.html"> <img src="admin/<?php echo $value['image'];?>" alt="" /></a>
					</div>
				    <div class="text list_2_of_1">
						<?php
					    $flag=0;
					    $now=date('Y-m-d');
					    $deadline=$value['deadline'];
					    if(strtotime($now)>strtotime($deadline))
					    {
					    	$flag=1;

					?>
						<h2 style="background: red"><?php echo $value['companyName'];?></h2>
						<?php } else {?>
						<h2 style="background: green"><?php echo $value['companyName'];?></h2>
						<?php } ?>
						<p><?php echo $fm->textShorten($value['body']);?></p>
						<?php
						    if($flag==1)
						    {
						?>
						<h2><?php echo 'Time is up for Applying'?></h2>
						<?php } ?>
						<div class="button"><span><a href="details.php?did=<?php echo $value['jobid'];?>" class="details">Details</a></span></div>
				   </div>

			   </div>
			   <?php } }?>		
			</div>

		  <div class="clear"></div>
		</div>
			 <div class="header_bottom_right_images">
		   <!-- FlexSlider -->
             
			<section class="slider">
				  <div class="flexslider">
					<ul class="slides">
						<li><img src="images/11.jpg" alt=""/></li>
						<li><img src="images/22.jpg" alt=""/></li>
						<li><img src="images/33.jpg" alt=""/></li>
				    </ul>
				  </div>
	      </section>
<!-- FlexSlider -->
	    </div>
	  <div class="clear"></div>
  </div>	



  <a style="color:blue;font-size: 30px" href="index_alljob.php">More..</a>



 <div class="main">
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		<h3><span style="color:red">HOT</span> JOBS</h3>
    		</div>
    		<div class="clear"></div>
    	</div>
	      <div class="section group">
	      	<?php
	            $gethj = $jobdet->gethotcom();
	            if(isset($gethj))
	            {
	            	while($value=$gethj->fetch_assoc())
	            	{
	            		
	            		
	        ?>
				<div class="grid_1_of_4 images_1_of_4" >
					 <a href="#"><img style="height:200px; width:170px" src="admin/<?php echo $value['image'];?>" alt="" /></a>
					 <?php
					    $flag=0;
					    $now=date('Y-m-d');
					    $deadline=$value['deadline'];
					    if(strtotime($now)>strtotime($deadline))
					    {
					    	$flag=1;

					?>
						<h2 style="background: red"><?php echo $value['companyName'];?></h2>
						<?php } else {?>
						<h2 style="background: green"><?php echo $value['companyName'];?></h2>
						<?php } ?>
						<p><?php echo $fm->textShorten($value['body']);?></p>
						<?php
						    if($flag==1)
						    {
						?>
						<h2><?php echo 'Time is up for Applying'?></h2>
						<?php } ?>
				     <div class="button"><span><a href="details.php?did=<?php echo $value['jobid'];?>" class="details">Details</a></span></div>
				     
				</div>
				<?php }   }?>
			</div>
			
   <div class="footer">
   	  <div class="wrapper">	
	     <div class="section group">
				<div class="col_1_of_4 span_1_of_4">
						<h4>About Us</h4>
						<ul>
						<li><a href="#">About Bdjobs.com</a></li>
						<li><a href="#">Terms and Conditions</a></li>
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="#">Feedback</a></li>
						<li><a href="#">Contact Us</a></li>
						</ul>
					</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Job Seekers</h4>
						<ul>
						<li><a href="#">Create Account</a></li>
						<li><a href="#">Career Counciling</a></li>
						<li><a href="#">My Bdjobs</a></li>
						<li><a href="#">FAQ</a></li>
						<li><a href="#">Video Guides</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Employers</h4>
						<ul>
							<li><a href="#">Create Account</a></li>
							<li><a href="#">Products/Services</a></li>
							<li><a href="#">Post a job</a></li>
							<li><a href="#">FAQ</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Contact</h4>
						<ul>
							<li><span>+88-01680106407</span></li>
							<li><span>+88-01717614099</span></li>
						</ul>
						<div class="social-icons">
							<h4>Follow Us</h4>
					   		  <ul>
							      <li class="facebook"><a href="#" target="_blank"> </a></li>
							      <li class="twitter"><a href="#" target="_blank"> </a></li>
							      <li class="googleplus"><a href="#" target="_blank"> </a></li>
							      <li class="contact"><a href="#" target="_blank"> </a></li>
							      <div class="clear"></div>
						     </ul>
   	 					</div>
				</div>
			</div>
			
     </div>
    </div>
    <script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
	  			containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
	 		};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
    <link href="css/flexslider.css" rel='stylesheet' type='text/css' />
	  <script defer src="js/jquery.flexslider.js"></script>
	  <script type="text/javascript">
		$(function(){
		  SyntaxHighlighter.all();
		});
		$(window).load(function(){
		  $('.flexslider').flexslider({
			animation: "slide",
			start: function(slider){
			  $('body').removeClass('loading');
			}
		  });
		});
	  </script>
</body>
</html>
