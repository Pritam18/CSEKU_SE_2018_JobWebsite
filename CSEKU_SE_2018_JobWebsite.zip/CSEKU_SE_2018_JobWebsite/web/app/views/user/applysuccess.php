<?php include 'classes/jobdetails.php';
      include 'classes/application.php';
      include 'inc/header.php';
      $app = new Application();
?>
         
<div style="margin-bottom: 60px;
margin-top: 17px;
margin-left: 129px;" class="section group">

   
<?php
   if(isset($_GET['cid']) || isset($_GET['adminid']))
   {
        $jobid   = $_GET['jobid'];
        $adminid = $_GET['adminid'];
        $cid     = $_GET['cid'];
        $aplid   = Session::get('id');
        $id      = $app->getinformation($aplid);
        if($id == true)
         {
             $insertdata = $app->insertapplication($jobid,$cid,$aplid,$adminid);
             if($insertdata == true)
             {
   ?>
                 <h3 style="color:green; text-align:center;margin-bottom: 30px;font-size: 40px;margin-top: 30px">  <?php echo 'Apply succesfully Completed'; ?></h3>
             <?php } 
             else { ?>
                 <h3 style="color:red; text-align: center;margin-bottom: 30px;font-size: 40px;margin-top: 30px">  <?php echo 'Apply not succesfully completed please try'; ?></h3>
             <?php } ?>

        <?php } 
        else { ?> 
            <h3 style="color:red; text-align: center;margin-bottom: 30px;font-size: 40px;margin-top: 30px">  <?php echo 'You are not applicable for apply. Please At First Login'; ?></h3>
        <?php } ?>
    <?php } ?>
  </div>
<?php include 'inc/footer.php';?>