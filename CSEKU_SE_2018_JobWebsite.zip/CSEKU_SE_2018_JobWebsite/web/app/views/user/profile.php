<?php include 'inc/header.php';?>
<?php 
	$login = Session::get("userlogin");
	if ($login == false) {
		header("Location:login.php");
	}
?>
<?php 

	$user = new User();
	$application = new Application();  

 ?>
<style>
.tblone{width: 550px;margin: 0 auto;border:2px solid #ddd;}
.tblone tr td{text-align: justify;}
</style>
 <div class="main">
    <div class="content">
    	<?php 
    		$getappid=$application->getinformation( Session::get("id"));
    	 ?>
    	<div class="section group">
    	 <?php  
    	 	$id      = Session::get("id");
    	 	$getdata = $user->getUserData($id);
    	 	if ($getdata) {
    	 		while ($result = $getdata->fetch_assoc()) {
    	 ?>
			<table class="tblone">
				`<tr>
					<td colspan="4"><h2>Your Profile Details</h2></td>
				</tr>
				<tr>
					<td width="20%">Name</td>
					<td width="5%">:</td>
					<td><?php echo $result['FullName']; ?></td>
					<td></td>
				</tr>
				<tr>
					<td>Email</td>
					<td>:</td>
					<td><?php echo $result['Email']; ?></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<?php 
					   if($getappid==true)
					   {
					 ?>
					<td><a href="personalinfo.php">Personal Information</a></td>
					<?php } else { ?>
					<td><a href="apply.php">Create Profile</a></td>
					<?php } ?>
				</tr>
			</table>
			<?php } } ?>
 		</div>
 	</div>
</div>

   <?php include 'inc/footer.php';?>