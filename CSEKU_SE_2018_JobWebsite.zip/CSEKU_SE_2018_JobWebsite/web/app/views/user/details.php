<?php 
      include 'classes/jobdetails.php';
      include 'classes/application.php';

      include 'inc/header.php';

?>

<?php
   $app=new Application();
   $application = new Application(); 
?>
<?php
    $jobdet = new Jobdetails();
    $fm     = new Format();
    
    
?>
<?php
    if(isset($_GET['did']))
    {
    	$did = $_GET['did'];
    }

?>


  <?php 
    	$getappid=$application->getinformation(Session::get("id"));	
    ?>			
<div style="margin-bottom: 60px;
margin-top: 17px;
margin-left: 129px;" class="section group">


	<?php
   
        $de = $jobdet->jobdetails($did);
        if(isset($de))
        {
        	while($value = $de->fetch_assoc())
        	{
            
?>
                   <div class="listview_1_of_2 images_1_of_2 " style="height: 300px">
				
					<div class="listimg listimg_2_of_1">
						 <a href="#"> <img style="height:150px;width:120px" src="admin/<?php echo $value['image'];?>" alt="" /></a>
					</div>
				    <div class="text list_2_of_1">
						<?php
					    $flag=0;
					    $now=date('Y-m-d');
					    $deadline=$value['deadline'];
					    if(strtotime($now)>strtotime($deadline))
					    {
					    	$flag=1;

					?>
						<h2 style="background: red;color:white"><?php echo $value['companyName'];?></h2>
						<?php } else {?>
						<h2 style="background: green"><?php echo $value['companyName'];?></h2>
						<?php } ?>
						<p><?php echo $fm->textShorten($value['body']);?></p>
						<?php
						    if($flag==1)
						    {
						?>
						<h2><?php echo 'Time is up for Applying'?></h2>
						<?php } ?>
						<h3>Designation : <?php echo $value['designation'];?></h3>
						<h3>Location : <?php echo $value['location'];?></h3>
						<h3>Experience : <?php echo $value['experience'];?></h3>
						<h3>Salary : <?php echo $value['salary'];?></h3>
						<h3>Available Post : <?php echo $value['apost'];?></h3>
						<p>Description:<?php echo $fm->textShorten($value['body']);?></p>
						<h3>Dead Line : <?php echo $value['deadline'];?></h3>
						<?php 
						   if($getappid == true && Session::get("userlogin")==true )
						   {
						 ?>
						<div class="button"><span><a href="applysuccess.php?cid=<?php echo $value['companyId'];?>&adminid=<?php echo $value['adminId'];?>&jobid=<?php echo $value['jobid'];?>">Apply</a></span></div>
						<?php } ?>
				   </div>
				   
				</div>
				<?php } } ?>
			</div>
   <div class="footer">
   	  <div class="wrapper">	
	     <div class="section group">
				<div class="col_1_of_4 span_1_of_4">
						<h4>About Us</h4>
						<ul>
						<li><a href="#">About Bdjobs.com</a></li>
						<li><a href="#">Terms and Conditions</a></li>
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="#">Feedback</a></li>
						<li><a href="#">Contact Us</a></li>
						</ul>
					</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Job Seekers</h4>
						<ul>
						<li><a href="#">Create Account</a></li>
						<li><a href="#">Career Counciling</a></li>
						<li><a href="#">My Bdjobs</a></li>
						<li><a href="#">FAQ</a></li>
						<li><a href="#">Video Guides</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Employers</h4>
						<ul>
							<li><a href="#">Create Account</a></li>
							<li><a href="#">Products/Services</a></li>
							<li><a href="#">Post a job</a></li>
							<li><a href="#">FAQ</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Contact</h4>
						<ul>
							<li><span>+88-01680106407</span></li>
							<li><span>+88-01717614099</span></li>
						</ul>
						<div class="social-icons">
							<h4>Follow Us</h4>
					   		  <ul>
							      <li class="facebook"><a href="#" target="_blank"> </a></li>
							      <li class="twitter"><a href="#" target="_blank"> </a></li>
							      <li class="googleplus"><a href="#" target="_blank"> </a></li>
							      <li class="contact"><a href="#" target="_blank"> </a></li>
							      <div class="clear"></div>
						     </ul>
   	 					</div>
				</div>
			</div>
			
     </div>
    </div>
    <script type="text/javascript">
		$(document).ready(function() {
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
    <link href="css/flexslider.css" rel='stylesheet' type='text/css' />
	  <script defer src="js/jquery.flexslider.js"></script>
	  <script type="text/javascript">
		$(function(){
		  SyntaxHighlighter.all();
		});
		$(window).load(function(){
		  $('.flexslider').flexslider({
			animation: "slide",
			start: function(slider){
			  $('body').removeClass('loading');
			}
		  });
		});
	  </script>
</body>
</html>
