<?php include 'classes/jobdetails.php';?>

<?php
    $jobdet=new Jobdetails();
    
?>
<?php 
	include 'lib/Session.php';
	Session::init();
   // include 'lib/Database.php';
	//include 'helpers/Format.php';

	spl_autoload_register(function($class){
		include_once "classes/".$class.".php";
	});

	//$db  = new Database();
	//$fm  = new Format();
	 // $user = new User();
 ?>

<!DOCTYPE HTML>
<head>
<title>Job Website</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/menu.css" rel="stylesheet" type="text/css" media="all"/>
<script src="js/jquerymain.js"></script>
<script src="js/script.js" type="text/javascript"></script>
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script> 
<script type="text/javascript" src="js/nav.js"></script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script> 
<script type="text/javascript" src="js/nav-hover.js"></script>
<link href='http://fonts.googleapis.com/css?family=Monda' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Doppio+One' rel='stylesheet' type='text/css'>
<script type="text/javascript">
  $(document).ready(function($){
    $('#dc_mega-menu-orange').dcMegaMenu({rowItems:'4',speed:'fast',effect:'fade'});
  });
</script>
</head>
<body>
  <div class="wrap">
		<div class="header_top">
			<div class="logo">
				<a href="#"><img style="height:130px;weight:170px" src="images/logo1.png" alt="" /></a>
			</div>
			  <div class="header_top_right">
			    <div class="search_box">
				    <form name="form" action='searchjob.php' method="post">
				    	<select style="margin-left: 0px;height: 36px;width: 257px;"   name="search" onchange="if (this.options[this.selectedIndex].value =='date'){(document.form['date'].style.visibility='visible' )&& (document.form['date1'].style.visibility='visible')}else {(document.form['date'] .style.visibility='hidden')&& (document.form['date1'].style.visibility='hidden')};">
				    		 <option value="B">Select....</option>
				    		 <optgroup label="Category">
				    		 	<?php
				    		 	   $db = new mysqli('localhost','root','','db_job');
				    		 	   $Result=$db->query("select * from tbl_category");
				    		 	   if($Result->num_rows>0)
				    		 	   {
				    		 	   	    while ($value = $Result->fetch_assoc())
				    		 	   	    {
				    		 	?>
				    		 	<option value="<?php echo $value['catId'];?>"><?php echo $value['catName'];?></option>
				    		 	<?php } }?>
				    		 </optgroup>
				    		 
                            
                             
                             <option value="date">Date Range</option>
                             
                        </select>
                        <table>
                        	<tr>
                        	   <td><input type="date" name="date" style="visibility:hidden;"/></td>
                        	   <td><input type="date" name="date1" style="visibility:hidden;"/></td>
                        	   
                            </tr>
                        </table>
				    	<input style="margin-top: -1px;height:37px" name="submit"type="submit" value="SEARCH">
				    </form>
			    </div>


<!--REPEAT -->


			  

                
               
  <div class="search_box">
				    <form name="form1" action='searchjob.php' method="post">
				    	<input type="text" placeholder="Search.." name="search1">
                        
				    	<input style="margin-top: -1px;height:37px" name="submit1" type="submit" value="SEARCH">
				    </form>
			    </div>






			    
		 <div class="clear"></div>
	 </div>
	 <div class="clear"></div>
 </div>
<div class="menu">
	<ul id="dc_mega-menu-orange" class="dc_mm-orange">
	  <li><a href="index.php">Home</a></li>
	  
	  <?php 
	  		$login = Session::get("userlogin");
	  		if ($login == true) { ?>
	            <li><a href="profile.php">Profile</a> </li>
	            <li><a href="?uid=<?php Session::get('id')?>">Logout</a></li>
	            <li><a href="alljob.php">JOBS</a> </li>
	            

	  <?php } 
	  		else
	  		{ ?>
	  			 <li><a href="login.php">LOGIN</a></li>
	   <?php 
	  	}
	  ?>
	   
	  
	  <li><a href="contact.php">Contact</a> </li>
	  <div class="clear"></div>
	</ul>
</div>

			
			<div class="section group">




 <?php
   
        $output = NULL;

        if (isset($_POST['submit1'])) {
        $db1 = new mysqli('localhost','root','','db_job');
        $search = $db->real_escape_string($_POST['search1']);
        if (empty($search)) 
        {
             header("Location:index.php");
        }
        else
        {
           $Result1 = $db1->query("SELECT * FROM tbl_company WHERE companyName LIKE '%$search%'");
           //$Result1 = $db1->query("SELECT designation FROM tbl_companydetails  WHERE designation LIKE '%$search%'");
            if ($Result1->num_rows>0)
            {
                 while ($value = $Result1->fetch_assoc())
                 {
                 	$id=$value['companyId'];
                 	$name=$value['companyName'];

                 	$Result2 = $db->query("SELECT * FROM tbl_companydetails  WHERE companyId='$id' AND publish=3 ");

                    if ($Result2->num_rows>0)
                   {
                       while ($value1 = $Result2->fetch_assoc())
                       {

                 
?>
                   <div class="listview_1_of_2 images_1_of_2">
				
					<div class="listimg listimg_2_of_1">
						 <a href="preview.html"> <img style="height:150px;width:120px" src="admin/<?php echo $value1['image'];?>" alt="" /></a>
					</div>
				    <div class="text list_2_of_1">
				    	
				    	
						<h2><?php echo $value['companyName'];?></h2>
						<p><?php echo $value1['body'];?></p>
						<div class="button"><span><a href="details.php?did=<?php echo $value1['jobid'];?>" class="details">Details</a></span></div>
				   </div>
				   
				</div>
				<?php } } } } } }?>







	<?php
   
        $output = NULL;

        if (isset($_POST['submit'])) {
        $db = new mysqli('localhost','root','','db_job');
        $search = $db->real_escape_string($_POST['search']);
        if (empty($search)) 
        {
             header("Location:index.php");
        }
        else
        {
           //$Result = $db->query("SELECT * FROM tbl_companydetails  WHERE designation LIKE '%$search%' OR body LIKE 
           	//'%$search%' OR location LIKE  '%$search%' ");
           //	if($search!="Date")
        	$start_date=$_POST['date'];
		    $end_date=$_POST['date1'];
           		$Result = $db->query("SELECT * FROM tbl_companydetails where publish=3 AND categoryId LIKE '%$search%' or companyId LIKE '%$search%' or deadline between '$start_date' and '$end_date'");
           
            if ($Result->num_rows>0)
            {
                 while ($value = $Result->fetch_assoc())
                 {

                 
?>
                   <div class="listview_1_of_2 images_1_of_2">
				
					<div class="listimg listimg_2_of_1">
						 <a href="preview.html"> <img style="height:150px;width:120px" src="admin/<?php echo $value['image'];?>" alt="" /></a>
					</div>
				    <div class="text list_2_of_1">
				    	<?php
				    	     $ci=$value['companyId'];
				    	     $Result1 = $db->query("SELECT companyName FROM tbl_company where  companyId ='$ci'");
				    	    // $Result1 = $db->query("SELECT com.companyName, cd.body FROM tbl_company as com ,tbl_companydetails as cd,where  com.companyId ='$ci' and com.companyId=cd.companyId");
				    	     if($Result1->num_rows>0)
				    	     {
				    	     	$value1=$Result1->fetch_assoc();

				    	?>
				    	
						<h2><?php echo $value1['companyName'];?></h2>
						<?php }?>
						<p><?php echo $value['body'];?></p>
						<div class="button"><span><a href="details.php?did=<?php echo $value['jobid'];?>" class="details">Details</a></span></div>
				   </div>
				   
				</div>
				<?php } } else { ?>
				     <h3 style="color:red; text-align: center;margin-bottom: 30px;font-size: 40px;margin-top: 30px">  <?php echo 'Item is not found'; ?></h3>
				<?php } } }?>
			</div>






      <!--REPEAT-->






   <div class="footer">
   	  <div class="wrapper">	
	     <div class="section group">
				<div class="col_1_of_4 span_1_of_4">
						<h4>About Us</h4>
						<ul>
						<li><a href="#">About Bdjobs.com</a></li>
						<li><a href="#">Terms and Conditions</a></li>
						<li><a href="#">International Partners</a></li>
						<li><a href="#">Other Part</a></li>
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="#">Feedback</a></li>
						<li><a href="#">Contact Us</a></li>
						</ul>
					</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Job Seekers</h4>
						<ul>
						<li><a href="#">Create Account</a></li>
						<li><a href="#">Career Counciling</a></li>
						<li><a href="#">My Bdjobs</a></li>
						<li><a href="#">FAQ</a></li>
						<li><a href="#">Video Guides</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Employers</h4>
						<ul>
							<li><a href="#">Create Account</a></li>
							<li><a href="#">Products/Services</a></li>
							<li><a href="#">Post a job</a></li>
							<li><a href="#">FAQ</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Contact</h4>
						<ul>
							<li><span>+88-01713458599</span></li>
							<li><span>+88-01813458552</span></li>
						</ul>
						<div class="social-icons">
							<h4>Follow Us</h4>
					   		  <ul>
							      <li class="facebook"><a href="#" target="_blank"> </a></li>
							      <li class="twitter"><a href="#" target="_blank"> </a></li>
							      <li class="googleplus"><a href="#" target="_blank"> </a></li>
							      <li class="contact"><a href="#" target="_blank"> </a></li>
							      <div class="clear"></div>
						     </ul>
   	 					</div>
				</div>
			</div>
			
     </div>
    </div>
    <script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
	  			containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
	 		};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
    <link href="css/flexslider.css" rel='stylesheet' type='text/css' />
	  <script defer src="js/jquery.flexslider.js"></script>
	  <script type="text/javascript">
		$(function(){
		  SyntaxHighlighter.all();
		});
		$(window).load(function(){
		  $('.flexslider').flexslider({
			animation: "slide",
			start: function(slider){
			  $('body').removeClass('loading');
			}
		  });
		});
	  </script>
</body>
</html>
