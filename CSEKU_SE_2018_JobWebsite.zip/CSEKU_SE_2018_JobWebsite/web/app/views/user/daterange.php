<?php include 'classes/jobdetails.php';?>

<?php
    $jobdet=new Jobdetails();
    
?>


<!DOCTYPE HTML>
<head>
<title>Job Website</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/menu.css" rel="stylesheet" type="text/css" media="all"/>
<script src="js/jquerymain.js"></script>
<script src="js/script.js" type="text/javascript"></script>
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script> 
<script type="text/javascript" src="js/nav.js"></script>
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script> 
<script type="text/javascript" src="js/nav-hover.js"></script>
<link href='http://fonts.googleapis.com/css?family=Monda' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Doppio+One' rel='stylesheet' type='text/css'>
<script type="text/javascript">
  $(document).ready(function($){
    $('#dc_mega-menu-orange').dcMegaMenu({rowItems:'4',speed:'fast',effect:'fade'});
  });
</script>
</head>
<body>
  <div class="wrap">
		<div class="header_top">
			<div class="logo">
				<a href="#"><img style="height:130px;weight:170px" src="images/logo1.png" alt="" /></a>
			</div>
			  <div class="header_top_right">
			    <div class="search_box">
				    <form action='searchjob.php' method="post">
				    	<select name="search">
				    		 <option value="B">Select....</option>
				    		 <optgroup label="Category">
				    		 	<?php
				    		 	   $db = new mysqli('localhost','root','','db_job');
				    		 	   $Result=$db->query("select * from tbl_category");
				    		 	   if($Result->num_rows>0)
				    		 	   {
				    		 	   	    while ($value = $Result->fetch_assoc())
				    		 	   	    {
				    		 	?>
				    		 	<option value="<?php echo $value['catId'];?>"><?php echo $value['catName'];?></option>
				    		 	<?php } }?>
				    		 </optgroup>
				    		 <optgroup label="Company">
				    		 	<?php
				    		 	   $db = new mysqli('localhost','root','','db_job');
				    		 	   $Result=$db->query("select * from tbl_company");
				    		 	   if($Result->num_rows>0)
				    		 	   {
				    		 	   	    while ($value = $Result->fetch_assoc())
				    		 	   	    {
				    		 	?>
				    		 	<option value="<?php echo $value['companyId'];?>"><?php echo $value['companyName'];?></option>
				    		 	<?php } }?>
				    		 </optgroup>
                            
                             <option value="B">Job nature</option>
                             <option value="C">Date</option>
                             <option value="D">Recent</option>
                        </select>
				    	<input name="submit"type="submit" value="SEARCH">
				    </form>
			    </div>
			    
		 <div class="clear"></div>
	 </div>
	 <div class="clear"></div>
 </div>
<div class="menu">
	<ul id="dc_mega-menu-orange" class="dc_mm-orange">
	  <li><a href="index.php">Home</a></li>
	  <li><a href="#">JOBS</a> </li>
	  <li><a href="#">MYJOBS</a></li>
	  <li><a href="#">TRAINING</a></li>
	   <li><a href="#">EMPLOYERS</a></li>
	  <li><a href="#">Contact</a> </li>
	  <div class="clear"></div>
	</ul>
</div>

			
			<div class="section group">
	<?php
   
        $output = NULL;

        if (isset($_POST['submit'])) {
        $db = new mysqli('localhost','root','','db_job');
        $search = $db->real_escape_string($_POST['search']);
        if (empty($search)) 
        {
             header("Location:index.php");
        }
        else
        {
           //$Result = $db->query("SELECT * FROM tbl_companydetails  WHERE designation LIKE '%$search%' OR body LIKE 
           	//'%$search%' OR location LIKE  '%$search%' ");
           	$Result = $db->query("SELECT * FROM tbl_companydetails where categoryId LIKE '%$search%' or companyId LIKE '%$search%'");
            if ($Result->num_rows>0)
            {
                 while ($value = $Result->fetch_assoc())
                 {

                 
?>
                   <div class="listview_1_of_2 images_1_of_2">
				
					<div class="listimg listimg_2_of_1">
						 <a href="preview.html"> <img style="height:150px;width:120px" src="admin/<?php echo $value['image'];?>" alt="" /></a>
					</div>
				    <div class="text list_2_of_1">
				    	
				    	
						<h2><?php echo $value['companyName'];?></h2>
						<p><?php echo $value['body'];?></p>
						<div class="button"><span><a href="details.php?did=<?php echo $value['companyId'];?>" class="details">Details</a></span></div>
				   </div>
				   
				</div>
				<?php } } } }?>
			</div>
   <div class="footer">
   	  <div class="wrapper">	
	     <div class="section group">
				<div class="col_1_of_4 span_1_of_4">
						<h4>About Us</h4>
						<ul>
						<li><a href="#">About Bdjobs.com</a></li>
						<li><a href="#">Terms and Conditions</a></li>
						<li><a href="#">International Partners</a></li>
						<li><a href="#">Other Part</a></li>
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="#">Feedback</a></li>
						<li><a href="#">Contact Us</a></li>
						</ul>
					</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Job Seekers</h4>
						<ul>
						<li><a href="#">Create Account</a></li>
						<li><a href="#">Career Counciling</a></li>
						<li><a href="#">My Bdjobs</a></li>
						<li><a href="#">FAQ</a></li>
						<li><a href="#">Video Guides</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Employers</h4>
						<ul>
							<li><a href="#">Create Account</a></li>
							<li><a href="#">Products/Services</a></li>
							<li><a href="#">Post a job</a></li>
							<li><a href="#">FAQ</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Contact</h4>
						<ul>
							<li><span>+88-01713458599</span></li>
							<li><span>+88-01813458552</span></li>
						</ul>
						<div class="social-icons">
							<h4>Follow Us</h4>
					   		  <ul>
							      <li class="facebook"><a href="#" target="_blank"> </a></li>
							      <li class="twitter"><a href="#" target="_blank"> </a></li>
							      <li class="googleplus"><a href="#" target="_blank"> </a></li>
							      <li class="contact"><a href="#" target="_blank"> </a></li>
							      <div class="clear"></div>
						     </ul>
   	 					</div>
				</div>
			</div>
			
     </div>
    </div>
    <script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
	  			containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
	 		};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
    <link href="css/flexslider.css" rel='stylesheet' type='text/css' />
	  <script defer src="js/jquery.flexslider.js"></script>
	  <script type="text/javascript">
		$(function(){
		  SyntaxHighlighter.all();
		});
		$(window).load(function(){
		  $('.flexslider').flexslider({
			animation: "slide",
			start: function(slider){
			  $('body').removeClass('loading');
			}
		  });
		});
	  </script>
</body>
</html>
