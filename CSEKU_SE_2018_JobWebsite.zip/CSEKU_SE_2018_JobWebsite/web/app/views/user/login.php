<?php 
	include 'inc/header.php';
	include 'classes/user.php';
?>
<?php 
	
	$login = Session::get("userlogin");
	if ($login == true) {
		header("Location:404.php");
	}

    $user = new User();
    
?>
<?php

     if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['user_login'])) {

        $result = $user->userLogin($_POST);
    }
?>
 <div class="main">
    <div class="content">
    	<div class="login_panel" style="float:left;width:300px">
    	<?php 
    		if (isset($result)) {
    			echo $result;
    		}
    	?>
        	<h3 >Existing User</h3>
        	<p>Sign in with the form below.</p>
        	<form action="" method="post" >
            	<input name="email" placeholder="Email" type="text" >
                <input name="password" placeholder="password" type="password"/ >
                <div class="buttons"><div><button class="grey" name="user_login">Sign In</button></div></div>
           </form>
       </div>
            
		<?php
		
		     if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['user_register'])) {
		         $result = $user->userRegistration($_POST);
		    }
		?>

    	<div class="register_account" style="float: right;
    width: 504px;">
	    	<?php 
	    	
	    		if (isset($result)) {
	    			echo $result;
	    		}
	    	?>
    		<h3 >Register New Account</h3>
    		<form action="" method="post">
			    <table>
				   	<tbody>
						<tr class="ftable">
							<td>
								<div>
								    <input type="text" name="username" placeholder="User Name" />
								</div>
								<div>
									<input type="text" name="email" placeholder="Email" />
								</div>		        					
								<div>
									<input style="    width: 355px;height: 27px;margin-bottom: 11px;" type="password" name="password" placeholder="Password" />
								</div>
					    	</td>
					    </tr> 
				    </tbody>
			    </table> 
				<div class="search"><div><button class="grey" name="user_register">Create Account</button></div>
					   </div>
					   
			    <div class="clear"></div>
		    </form>
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>

<?php include 'inc/footer.php';?>