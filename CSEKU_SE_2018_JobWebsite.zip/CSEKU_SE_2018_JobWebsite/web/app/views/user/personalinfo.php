<?php include 'inc/header.php';?>


<?php 

	$application = new Application();  

 ?>
 <style>
.tblone{width: 550px;margin: 0 auto;border:2px solid #ddd;}
.tblone tr td{text-align: justify;}
</style>
 <div class="main">
    <div class="content">
    	<div class="section group">
    	 <?php
             $getallinfo=$application->getallinformation(Session::get("id"));
             if(isset($getallinfo))
             {
             	while($result=$getallinfo->fetch_assoc())
             	{
    	 ?>
			<table class="tblone">
				`<tr>
					<td colspan="3"><h2>Your Profile Details</h2></td>
				</tr>
				<tr>
					<td width="20%">First Name</td>
					<td width="5%">:</td>
					<td><?php echo $result['fname']; ?></td>
				</tr>
				<tr>
					<td width="20%">Last Name</td>
					<td width="5%">:</td>
					<td><?php echo $result['lname']; ?></td>
				</tr>
				<tr>
					<td>Father Name</td>
					<td>:</td>
					<td><?php echo $result['faname']; ?></td>
				</tr>
				<tr>
					<td>Mother Name</td>
					<td>:</td>
					<td><?php echo $result['moname']; ?></td>
				</tr>
				<tr>
					<td>Gender</td>
					<td>:</td>
					<td><?php echo $result['gender']; ?></td>
				</tr>
				<tr>
					<td>Religion</td>
					<td>:</td>
					<td><?php echo $result['religion']; ?></td>
				</tr>
				<tr>
					<td>Marital_Status</td>
					<td>:</td>
					<td><?php echo $result['marital_status']; ?></td>
				</tr>
				<tr>
					<td>Nationality</td>
					<td>:</td>
					<td><?php echo $result['nationality']; ?></td>
				</tr>
				<tr>
					<td>Present Address</td>
					<td>:</td>
					<td><?php echo $result['presentaddress']; ?></td>
				</tr>
				<tr>
					<td>Permanent Address</td>
					<td>:</td>
					<td><?php echo $result['permanentaddress']; ?></td>
				</tr>

				<tr>
					<td>Email</td>
					<td>:</td>
					<td><?php echo $result['email']; ?></td>
				</tr>
				
			</table>
			<?php } } ?>
 		</div>
 	</div>
</div>

   <?php include 'inc/footer.php';?>