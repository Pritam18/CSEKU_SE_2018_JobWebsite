<?php 
    include 'classes/jobdetails.php';
    ?>
<?php  
  include 'inc/header.php';
?>
 <?php 
       $jobdet = new Jobdetails();
       $fm = new Format();
    
  ?>        
<div style="margin-bottom: 60px;
margin-top: 17px;
margin-left: 129px;" class="section group">
       <?php 
          $de = $jobdet->getAlljobFromIndex();
        if(isset($de))
        {
          while($value = $de->fetch_assoc())
          {
        ?> 
  <div style="border:1px solid #cecece;background: #ddd;height: 200px">
           
   <div>
   
     <p style=" padding-top: 5px;padding-left: 5px;font-size: 15px;font-weight: bold;color: #286090"><a href='#'><?php echo $value['companyName'];?></a></p>
      <p style=" padding-top: 5px;padding-left: 5px;font-size: 15px;font-weight: bold;color: #286090"><a href='#'>Post:<span style="color: #286090"><?php echo $value['apost'];?></span></a></p>
       <p style=" padding-top: 5px;padding-left: 5px;font-size: 15px;font-weight: bold;color: #286090"><a href='#'>Designation:<span style="color: #286090"><?php echo $value['designation'];?></span></a></p>
       <p style=" padding-top: 5px;padding-left: 5px;font-size: 15px;font-weight: bold;color: #286090"><a href='#'>Dead Line:<span style="color: #286090"><?php echo $value['deadline'];?></span></a></p>
     <p style="padding-top: 5px;padding-left: 5px;font-size: 15px;font-weight: bold;color: #286090"">Location: <span style="color: #286090"><?php echo $value['location'];?></span><br><br><a href='#'><?php echo $fm->textShorten($value['body']);?></a></p><br>
     <div class="button"><span><a href="applysuccess.php?cid=<?php echo $value['companyId'];?>&adminid=<?php echo $value['adminId'];?>&jobid=<?php echo $value['jobid'];?>"><span style="background-color: green;color: white;padding: 5px;margin-left: 15px">Apply</span></a></span></div>
   </div>
 </div><br>
 <?php } } ?>

</div>
<?php include 'inc/footer.php';?>
