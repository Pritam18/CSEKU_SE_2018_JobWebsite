
<?php 
    include 'classes/jobdetails.php';
    ?>
<?php  
  include 'inc/header.php';
?>
 <?php 
       $jobdet = new Jobdetails();
       $fm = new Format();
    
  ?>      

<style>
.pagination{display:block;font-size: 20px;padding: 10px;margin-top: 10px;text-align: center;}
.pagination a{background: #e6af4b none repaet scroll 0 0;
border:1px solid #a7700c;
border-radius: 3px;
color:#333;
margin-left: 2px;
padding: 2px 10px;
text-decoration: none}
.pagination a:hover{background:white none repaet scroll 0 0;}



.pagination1{display:block;font-size: 20px;padding: 10px;margin-top: 10px;text-align: center;margin-top: 20px}
.pagination1 a{background: #e6af4b none repaet scroll 0 0;
border:1px solid #a7700c;
border-radius: 3px;
color:#333;
margin-left: 2px;
padding: 2px 10px;
text-decoration: none}
.pagination1 a:hover{background:white none repaet scroll 0 0;}


.pagination2{display:block;font-size: 20px;padding: 10px;margin-top: 10px;text-align: center;margin-top: 20px}
.pagination2 a{background: #e6af4b none repaet scroll 0 0;
border:1px solid #a7700c;
border-radius: 3px;
color:#333;
margin-left: 2px;
padding: 2px 10px;
text-decoration: none}
.pagination2 a:hover{background:white none repaet scroll 0 0;}

.bb{   margin-top:-102px;
    margin-left: 438px;}
.bb1{  margin-bottom: -53px;
    margin-left: -345px;}
.button{margin-top: 200px;
    margin-left: 198px;}
    .button a{
  padding:7px 15px;
    font-size:0.8em;
    font-family: Arial, "Helvetica Neue", "Helvetica", Tahoma, Verdana, sans-serif;
    border: 1px solid rgba(0,0,0,0.1);
        background:#602D8D url(../images/large-button-overlay.png);       
        color             : #fff;
        text-shadow:0 -1px 1px rgba(0, 0, 0, 0.25);
    -moz-border-radius:5px;
    -webkit-border-radius:5px;
    border-radius:5px;
    
}
button a:hover{
      border: 1px solid #4D00A0;
        background:#70389C;
        text-decoration:none; 
}
</style>


<?php
    $per_page=3;
    if(isset($_GET['page']))
    {
      $page=$_GET['page'];
    }
    else
    {
      $page=1;
    }
    $start_form=($page-1)*$per_page;
?>
  
<div style="margin-bottom: 60px;
margin-top: 17px;
margin-left: 129px;" class="section group">
       <?php 
          //$de = $jobdet->getallcompanydetails2();
        $db = new mysqli('localhost','root','','db_job');
        
        $result=$db->query("SELECT cd.*,com.companyName 
            FROM tbl_companydetails as cd,tbl_company as com WHERE cd.companyId = com.companyId and cd.publish=3 limit $start_form,$per_page ");
        if($result)
        {
          while($value = $result->fetch_assoc())
          {
        ?> 
  <div style="border:1px solid #cecece;background: #ddd;height: 200px">
           
   <div>





<?php
              $flag=0;
              $now=date('Y-m-d');
              $deadline=$value['deadline'];
              if(strtotime($now)>strtotime($deadline))
              {
                $flag=1;

          ?>
            <h2 style="margin-left:177px;background: red;padding-top: 5px;padding-left: 5px;font-size: 15px;font-weight: bold;"><?php echo $value['companyName'];?></h2>
            <?php } else {?>
            <h2 style="margin-left:177px;background: green;padding-top: 5px;padding-left: 5px;font-size: 15px;font-weight: bold;"><?php echo $value['companyName'];?></h2>
            <?php } ?>



   
      <a href="#"><img style="height:200px; width:170px;margin-top:-20px" src="admin/<?php echo $value['image'];?>" alt="" /></a>
      <p style=" margin-left:177px;padding-top: 5px;padding-left: 5px;margin-bottom:-177px;font-size: 15px;font-weight: bold;color: #286090"></p>
       <p style=" margin-left:177px;padding-top: 5px;padding-left: 5px;margin-bottom:-177px;font-size: 15px;font-weight: bold;color: #286090"><a href='#'>Designation:<span style="color: #286090"><?php echo $value['designation'];?></span></a></p>

       
     <div class="button"> <a href="details.php?did=<?php echo $value['jobid'];?>" class="details">Details</a></div>
     <?php
                if($flag==1)
                {
            ?>
            <h2><?php echo 'Time is up for Applying'?></h2>
            <?php } ?>
        </a>

   </div>

 </div><br>

 <?php } } ?>


 <?php

   if(isset($_GET['page']))
 {
   $pag=$_GET['page'];
   $pag=$pag-1;?>
   <div class='bb1'>
   <?php echo "<span class='pagination2'><a href='index_alljob.php?page=$pag'>".'previous page'."</a></span>";?>
 </div>
   <?php } ?>
 

 <?php 
    $db = new mysqli('localhost','root','','db_job');
    $Result=$db->query("select * from tbl_companydetails where publish=3");
    $total_rows=mysqli_num_rows($Result);
    $total_pages=ceil($total_rows/$per_page);

   echo "<span class='pagination'>";
  for($i=1;$i<=$total_pages;$i++)
  {
    echo "<a href='index_alljob.php?page=".$i."'>".$i."</a>";
  }
  

   echo "</span>"?>
 


</div>


<?php

   if(isset($_GET['page']))
 {
   $pag=$_GET['page'];
   $pag=$pag+1;?>
   <div class='bb'>
   <?php echo "<span class='pagination1'><a href='index_alljob.php?page=$pag'>".'next page'."</a></span>";?>
 </div>
   <?php } ?>



   







<?php include 'inc/footer.php';?>
