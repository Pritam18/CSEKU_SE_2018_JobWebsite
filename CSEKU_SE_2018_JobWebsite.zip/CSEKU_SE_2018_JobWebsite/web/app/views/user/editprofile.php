<?php include 'inc/header.php';?>


<?php 

	$application = new Application();  
	if(isset($_GET['pid']))
	{
		$appid=$_GET['pid'];
	}

 ?>
 <?php

     if (isset($_GET['submit'])) {

        $value = $application->updateuserinformation($_GET,$appid);
    }
?>
 <style>
.tblone{width: 550px;margin: 0 auto;border:2px solid #ddd;}
.tblone tr td{text-align: justify;}
</style>
 <div class="main">
    <div class="content">
    	<div class="section group">
    	<?php
    	   if(isset($value))
    	   	echo $value;
    	?>
    	 <?php
             $getallinfo=$application->getallinformation(Session::get("id"));
             if(isset($getallinfo))
             {
             	while($result=$getallinfo->fetch_assoc())
             	{
    	 ?>
			<table class="tblone">
				`<tr>
					<td colspan="3"><h2>Your Profile Details</h2></td>
				</tr>
				<tr>
					<td width="20%">First Name</td>
					<td width="5%">:</td>
					<td><input name='fname' value='<?php echo $result['fname']; ?>'/></td>
				</tr>
				<tr>
					<td width="20%">Last Name</td>
					<td width="5%">:</td>
					<td><input name='lname' value='<?php echo $result['lname']; ?>'/></td>
				</tr>
				<tr>
					<td>Father Name</td>
					<td>:</td>
					<td><input name='faname' value='<?php echo $result['faname']; ?>'/></td>
				</tr>
				<tr>
					<td>Mother Name</td>
					<td>:</td>
					<td><input name='moname' value='<?php echo $result['moname']; ?>'/></td>
				</tr>
				<tr>
					<td>Gender</td>
					<td>:</td>
					<td><input name='gender' value='<?php echo $result['gender']; ?>'/></td>
				</tr>
				<tr>
					<td>Religion</td>
					<td>:</td>
					<td><input name='religion' value='<?php echo $result['religion']; ?>'/></td>
				</tr>
				<tr>
					<td>Marital_Status</td>
					<td>:</td>
					</td><td><input name='marital_status' value='<?php echo $result['marital_status']; ?>'/></td>

				</tr>
				<tr>
					<td>Nationality</td>
					<td>:</td>
					<td><input name='nationality' value='<?php echo $result['nationality']; ?>'/></td>
				</tr>
				<tr>
					<td>Present Address</td>
					<td>:</td>
					<td><input name='presentaddress' value='<?php echo $result['presentaddress']; ?>'/></td>
				</tr>
				<tr>
					<td>Permanent Address</td>
					<td>:</td>
					<td><input name='permanentaddress' value='<?php echo $result['permanentaddress']; ?>'/></td>
				</tr>

				<tr>
					<td>Email</td>
					<td>:</td>
					<td><input name='email' value='<?php echo $result['email']; ?>'/></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td><button type="submit" name="submit">Update</button></td>
				</tr>
			</table>
			<?php } } ?>
 		</div>
 	</div>
</div>

   <?php include 'inc/footer.php';?>