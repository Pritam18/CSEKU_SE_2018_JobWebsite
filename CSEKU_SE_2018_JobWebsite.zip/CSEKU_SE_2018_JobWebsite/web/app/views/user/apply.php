<?php 
include 'classes/application.php';
include 'inc/header.php';
?>

<?php
    $application = new Application();   
?>

<style>
input[type=text], select, textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    margin-top: 6px;
    margin-bottom: 16px;
    resize: vertical;
}

input[type=submit] {
    background-color: #4CAF50;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-top:4px";
}

input[type=submit]:hover {
    background-color: #45a049;
}

.container {
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 20px;
    width: 500px;
    margin-left: 272px;
}
h3{margin-top: 20px;
text-align: center;
margin-bottom: 20px;
font-size: 20px;
color: green;}
</style>
</head>
<body>
<?php
    if($_SERVER['REQUEST_METHOD']=="POST" && isset($_POST['submit']))
    {
        $result = $application->adduserinformation($_POST);
    }
?>
<h3>Application Form</h3>
<?php
     if(isset($result))
     	echo $result;
?>
<div class="container">
  <form action=""method="post">
    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname" placeholder="Your last name..">

    <label for="fname">Father's Name</label>
    <input type="text" id="fname" name="fathername" placeholder="Your Father's name..">

    <label for="mname">Mother's Name</label>
    <input type="text" id="mname" name="mothername" placeholder="Your Mother's name..">


    <label for="gender">Gender</label>
        <select id="gender" name="gender">
	      <option value="Male">Male</option>
	      <option value="Female">Female</option>
	    </select>

    <label for="religion">Religion</label>
    <input type="text" id="religion" name="religion" placeholder="Religion..">

     <label for="mstatus">Marital Status</label>
        <select id="mstatus" name="mstatus">
	      <option value="Married">Married</option>
	      <option value="Unmarried">Unmarried</option>
	    </select>

    <label for="country">Nationality</label>
	    <select id="country" name="country">
	      <option value="australia">Australia</option>
	      <option value="canada">Canada</option>
	      <option value="usa">USA</option>
	      <option value="bangladesh">Bangladesh</option>
	      <option value="india">India</option>
	      <option value="srilanka">Srilanka</option>
	      <option value="nepal">Nepal</option>
	      <option value="pakistan">Pakistan</option>
	    </select>

    <label for="nId">National Id No</label>
    <input type="text" id="nId" name="nId" placeholder="National Id No..">

    <label for="address">Present Address</label>
    <textarea id="address" name="address" placeholder="Present Address.." style="height:100px"></textarea>

    <label for="address">Permanent Address</label>
    <textarea id="address" name="paddress" placeholder="Parmanent Address.." style="height:100px"></textarea>

  <!--   <label for="phonnum1">Phone Number 1</label>
    <input type="text" id="phonnum1" name="phonnum1" placeholder="Phone Number 1..">

    <label for="phonnum2">Phone Number 2</label>
    <input type="text" id="phonnum2" name="phonnum2" placeholder="Phone Number 2.."> -->

    <label for="email">Email</label>
    <input type="text" id="email" name="email" placeholder="Email..">

    <input name="submit" type="submit" value="Submit">
  </form>
</div>

   <div class="footer">
   	  <div class="wrapper">	
	     <div class="section group">
				<div class="col_1_of_4 span_1_of_4">
						<h4>About Us</h4>
						<ul>
						<li><a href="#">About Bdjobs.com</a></li>
						<li><a href="#">Terms and Conditions</a></li>
						<li><a href="#">International Partners</a></li>
						<li><a href="#">Other Part</a></li>
						<li><a href="#">Privacy Policy</a></li>
						<li><a href="#">Feedback</a></li>
						<li><a href="#">Contact Us</a></li>
						</ul>
					</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Job Seekers</h4>
						<ul>
						<li><a href="#">Create Account</a></li>
						<li><a href="#">Career Counciling</a></li>
						<li><a href="#">My Bdjobs</a></li>
						<li><a href="#">FAQ</a></li>
						<li><a href="#">Video Guides</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Employers</h4>
						<ul>
							<li><a href="#">Create Account</a></li>
							<li><a href="#">Products/Services</a></li>
							<li><a href="#">Post a job</a></li>
							<li><a href="#">FAQ</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Contact</h4>
						<ul>
							<li><span>+88-01713458599</span></li>
							<li><span>+88-01813458552</span></li>
						</ul>
						<div class="social-icons">
							<h4>Follow Us</h4>
					   		  <ul>
							      <li class="facebook"><a href="#" target="_blank"> </a></li>
							      <li class="twitter"><a href="#" target="_blank"> </a></li>
							      <li class="googleplus"><a href="#" target="_blank"> </a></li>
							      <li class="contact"><a href="#" target="_blank"> </a></li>
							      <div class="clear"></div>
						     </ul>
   	 					</div>
				</div>
			</div>
			
     </div>
    </div>
    <script type="text/javascript">
		$(document).ready(function() {
			/*
			var defaults = {
	  			containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
	 		};
			*/
			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
    <link href="css/flexslider.css" rel='stylesheet' type='text/css' />
	  <script defer src="js/jquery.flexslider.js"></script>
	  <script type="text/javascript">
		$(function(){
		  SyntaxHighlighter.all();
		});
		$(window).load(function(){
		  $('.flexslider').flexslider({
			animation: "slide",
			start: function(slider){
			  $('body').removeClass('loading');
			}
		  });
		});
	  </script>
	  <script>
function myFunction() {
    var x = document.getElementById("myDate").value;
    document.getElementById("demo").innerHTML = x;
}
</script>
</body>
</html>
