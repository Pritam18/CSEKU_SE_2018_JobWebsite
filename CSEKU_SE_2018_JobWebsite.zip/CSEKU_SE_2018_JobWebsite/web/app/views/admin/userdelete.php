<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php include '../classes/catagory.php';?>
<?php include '../classes/company.php';?>
<?php include '../classes/jobdetails.php';?>
<?php 
   $com = new Company();
   $jobdet = new Jobdetails();
   $adId = Session::get("adminId");

   if (isset($_GET['deluser'])) {
   	$id     = $_GET['deluser'];
   	$deluser = $jobdet->deluserById($id);
   }

  
?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>User List</h2>
                <div class="block">   
                <?php 
                	if (isset($deluser)) {
                		echo $deluser;
                	}
                 ?>     
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Name</th>
							<th>Email</th>
							<th>Action</th>
							
						</tr>
					</thead>
					<tbody>
						<?php 
							$getuser = $jobdet->getAllUser();
							if ($getuser) {
								$i = 0;
								while ( $result = $getuser->fetch_assoc()) {
									$i++;
					      ?>						
							<tr class="odd gradeX">
								<td><?php echo $i; ?></td>
								<td><?php echo $result['FullName']; ?></td>
								<td><?php echo $result['Email']; ?></td>
								<td>
                             <a onclick="return confirm('Are you sure to delete!')" href="?deluser=<?php echo $result['id']; ?>">Delete</a> 	</td>
							</tr>

								
						<?php } } ?>

						
							
						</tbody>
				</table>
               </div>
            </div>
        </div>
<script type="text/javascript">
	$(document).ready(function () {
	    setupLeftMenu();

	    $('.datatable').dataTable();
	    setSidebarHeight();
	});
</script>
<script>
	function myFunction() {
    document.getElementById("publish").style.color = "green";
}
</script>
<?php include 'inc/footer.php';?>

