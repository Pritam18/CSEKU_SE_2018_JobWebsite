﻿<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php include '../classes/jobdetails.php';?>

<?php
     $jobdet = new Jobdetails();
     $companyId = Session::get("companyId");
    // echo $companyId;
     $catId   = Session::get("categoryId");
     //echo $catId;  
?>
<?php
    if($_SERVER['REQUEST_METHOD']=="POST" && isset($_POST['submit']))
    {
        $result=$jobdet->addjob($_POST,$_FILES,$companyId,$catId);
    }
?>
<div class="grid_10">
    <div class="box round first grid">
        <h2>Add Company Details</h2>
        <?php
            if(isset($result))
            {
                echo $result;
            }
        ?>
        <div class="block">               
         <form action="" method="post" enctype="multipart/form-data">
            <table class="form">
               
               
				<tr>
                    <td>
                        <label>Designation</label>
                    </td>
                    <td>
                        <input type="text" placeholder="Enter Designation Name..." class="medium" name="designationyname" >
                    </td>
                </tr>

                <tr>
                    <td>
                        <label>Location</label>
                    </td>
                    <td>
                        <input type="text" placeholder="Enter location..." class="medium" name="location" />
                    </td>
                </tr>

                <tr>
                    <td>
                        <label>Experience</label>
                    </td>
                    <td>
                        <input type="text"  class="medium" name="experience" />
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Salary</label>
                    </td>
                    <td>
                        <input type="text"  class="medium" name="salary" />
                    </td>
                </tr>

                <tr>
                    <td>
                        <label>Post Available</label>
                    </td>
                    <td>
                        <input type="text"  class="medium" name="apost" />
                    </td>
                </tr>
				
				
				 <tr>
                    <td style="vertical-align: top; padding-top: 9px;">
                        <label>Description</label>
                    </td>
                    <td>
                        <textarea class="tinymce" name="body"></textarea>
                    </td>
                </tr>
				           
                <tr>
                    <td>
                        <label>Upload Image</label>
                    </td>
                    <td>
                        <input type="file" name="image" />
                    </td>
                </tr>

                <tr>
                    <td>
                        <label>Dead Line</label>
                    </td>
                    <td>
                        <input type="date"  placeholder="year/month/day" class="medium" name="deadline" />
                    </td>
                </tr>
				
				<tr>
                    <td>
                        <label>Job Type</label>
                    </td>
                    <td>
                        <select id="select" name="type">
                            <option>Select Type</option>
                            <option value="0">New</option>
                            <option value="1">Hot</option>
                        </select>
                    </td>
                </tr>

				<tr>
                    <td></td>
                    <td>
                        <input type="submit" name="submit" Value="Save" />
                    </td>
                </tr>
            </table>
            </form>
        </div>
    </div>
</div>
<!-- Load TinyMCE -->
<script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function () {
        setupTinyMCE();
        setDatePicker('date-picker');
        $('input[type="checkbox"]').fancybutton();
        $('input[type="radio"]').fancybutton();
    });
</script>
<!-- Load TinyMCE -->
<?php include 'inc/footer.php';?>


