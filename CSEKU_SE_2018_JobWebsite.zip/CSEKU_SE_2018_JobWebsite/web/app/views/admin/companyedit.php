<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php include '../classes/catagory.php';?>
<?php include '../classes/company.php';?>
<?php
     if (!isset($_GET['companyid']) || $_GET['companyid'] == NULL ) {
        echo "<script>window.location = 'companylist.php'</script>";
     } else{
        $id = preg_replace('/[^-a-zA-Z0-9_]/','', $_GET['companyid']);
     }
     
     $com = new Company();
     if ($_SERVER['REQUEST_METHOD'] == 'POST') {
     $companyName = $_POST['companyName'];
     $updateCompany = $com->companyUpdate($companyName,$id);
    }
?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Update Company</h2>
               <div class="block copyblock"> 
               <?php 
                    if (isset($updateCompany)) {
                       echo $updateCompany; 
                    }
                ?>
                <?php 
                    $getCompany = $com->getComById($id);
                    if ($getCompany) {
                        $i = 0;
                        while ($value = $getCompany->fetch_assoc()) {
                            $i++;
                 ?>
                 <form action="" method="POST">
                    <table class="form">                    
                        <tr>
                            <td>
                                <label>Category</label>
                            </td>
                            <td>
                                <select id="select" name="catId">
                                    <option>Select Category</option>
                                    <?php 
                                        $cat    = new Catagory();
                                        $getCat = $cat->getAllCat();
                                        if ($getCat) {
                                            while ($result = $getCat->fetch_assoc()) {
                                     ?>
                                    <option value="<?php echo $result['catId']; ?>"><?php echo $result['catName']; ?></option>
                                    <?php } } ?>
                                </select>
                            </td>
                        </tr>

                        <tr> 
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input type="text" name="companyName" value="<?php echo $value['companyName']; ?>" class="medium" />
                            </td>
                        </tr>
                        <tr> 
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php } } ?>
                </div>
            </div>
        </div>
<?php include 'inc/footer.php';?>