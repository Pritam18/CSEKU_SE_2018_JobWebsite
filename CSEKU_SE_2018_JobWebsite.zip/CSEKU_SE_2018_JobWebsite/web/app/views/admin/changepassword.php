<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php
    $updatepass=new Adminlogin();
?>
<?php
    if($_SERVER['REQUEST_METHOD']='POST' && isset($_POST['submit']))
    {
        $result=$updatepass->changepassword($_POST);
    }
?>
    <div class="grid_10">
        <div class="box round first grid">
            <h2>Change Password</h2>
           <div class="block copyblock"> 
            <?php
                        if(isset($result))
                        {
                            echo $result;
                        }
                    ?>
                <form action="" method="POST">
                    
                    <table class="form">			
                        <tr>
                            <td>
                                <label>Name : </label>
                            </td>
                            <td>
                                <input type="text" name="userName" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Old Password : </label>
                            </td>
                            <td>
                                <input type="password" name="opass" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>New Password : </label>
                            </td>
                            <td>
                                <input type="password" name="npass" class="medium" />
                            </td>
                        </tr>
        				<tr> 
                            <td>
                                <input type="submit" name="submit" Value="change password" />
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>
<?php include 'inc/footer.php';?>