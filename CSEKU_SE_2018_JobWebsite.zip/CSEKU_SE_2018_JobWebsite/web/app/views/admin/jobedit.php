<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php include '../classes/jobdetails.php';?>
<?php
     if (!isset($_GET['jobid']) || $_GET['jobid'] == NULL ) {
        echo "<script>window.location = 'joblist.php'</script>";
     } else{
        $id = preg_replace('/[^-a-zA-Z0-9_]/','', $_GET['jobid']);
     }
     
     $jobdet = new Jobdetails();
     if ($_SERVER['REQUEST_METHOD'] == 'POST') {
     //$catName = $_POST['catName'];
     $updateJob = $jobdet->jobUpdate($_POST,$id);
    }
?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Update Category</h2>
               <div class="block copyblock"> 
               <?php 
                    if (isset($updateJob)) {
                       echo $updateJob; 
                    }
                ?>
                <?php 
                    $getJob = $jobdet->getJobById($id);
                    if ($getJob) {
                        $i = 0;
                        while ($result = $getJob->fetch_assoc()) {
                            $i++;
                 ?>
                 <form action="" method="POST">
                    <table class="form">					
                <tr>
                    <td>
                      <label>Designation</label>
                   </td>
                    <td>
                        <input type="text" name="designationname" value="<?php echo $result['designation']; ?>" class="medium" />
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Location</label>
                    </td>
                    <td>
                        <input type="text"  class="medium" value="<?php echo $result['location']; ?>" name="location" />
                    </td>
                </tr>

                <tr>
                    <td>
                        <label>Experience</label>
                    </td>
                    <td>
                        <input type="text"  class="medium" value="<?php echo $result['experience']; ?>" name="experience" />
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Salary</label>
                    </td>
                    <td>
                        <input type="text"  class="medium" value="<?php echo $result['salary']; ?>" name="salary" />
                    </td>
                </tr>

                <tr>
                    <td>
                        <label>Post Available</label>
                    </td>
                    <td>
                        <input type="text"  class="medium" value="<?php echo $result['apost']; ?>" name="apost" />
                    </td>
                </tr>
                
                
                 <tr>
                    <td style="vertical-align: top; padding-top: 9px;">
                        <label>Description</label>
                    </td>
                    <td>
                        <textarea class="tinymce"  name="body">
                            <?php echo $result['body']; ?>
                        </textarea>
                    </td>
                </tr>
                           
                <tr>
                    <td>
                        <label>Dead Line</label>
                    </td>
                    <td>
                        <input type="date"   class="medium" value="<?php echo $result['deadline']; ?>" name="deadline" />
                    </td>
                </tr>
                
                <tr>
                    <td>
                        <label>Job Type</label>
                    </td>
                    <td>
                        <select id="select" name="type">
                            <option>Select Type</option>
                            <option value="0">New</option>
                            <option value="1">Hot</option>
                        </select>
                    </td>
                </tr>
						<tr> 
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php } } ?>
                </div>
            </div>
        </div>
<?php include 'inc/footer.php';?>