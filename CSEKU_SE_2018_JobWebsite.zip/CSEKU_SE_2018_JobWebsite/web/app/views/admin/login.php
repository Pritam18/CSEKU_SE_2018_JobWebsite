<?php
   //include_once ($filepath.'/../lib/Session.php');
	include '../lib/Session.php';
	Session::checkLogin();
   include '../classes/adminLogin.php';
  
?>
<?php 
	$al = new Adminlogin();
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		$adminUserName = $_POST['adminUserName'];
		$adminPass = md5($_POST['adminPass']);

		$loginChk = $al->adminLogin($adminUserName,$adminPass);
	}
 ?>
<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Admin Login</title>
    <link rel="stylesheet" type="text/css" href="css/stylelogin.css" media="screen" />
</head>
<body>
<div class="container">
	<section id="content">
		<form action="login.php" method="post">
			<h1>Admin Login</h1>
			<span style="color: red;font-size: 18px;">
			<?php 
				if (isset($loginChk)) {
					echo $loginChk;
				}
			 ?>				
			</span>
			<div>
				<input type="text" placeholder="Username"  name="adminUserName"/>
			</div>
			<div>
				<input type="password" placeholder="Password"  name="adminPass"/>
			</div>
			<div>
				<input type="submit" value="Login" />
			</div>
		</form><!-- form -->
		<div class="button">
			<a href="#">Project Of Web Programming</a>
		</div><!-- button -->
	</section><!-- content -->
</div><!-- container -->
</body>
</html>