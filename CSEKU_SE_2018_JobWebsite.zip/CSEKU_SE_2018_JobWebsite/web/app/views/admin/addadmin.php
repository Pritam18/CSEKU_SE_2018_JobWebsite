<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php //include '../classes/adminLogin.php';?>
<?php include '../classes/catagory.php';?>
<?php include '../classes/company.php';?>

<?php
       $al = new Adminlogin();
      if ($_SERVER['REQUEST_METHOD'] == 'POST') {
      $addAdmin = $al->adminAdd($_POST);
     }
?>
<div class="grid_10">
    <div class="box round first grid">
        <h2>Add New Admin</h2>
        <div class="block"> 
        <?php 
             if (isset($addAdmin)) {
                 echo $addAdmin;
             }
         ?>              
         <form action="" method="post" >
            <table class="form">
               
                <tr>
                    <td>
                        <label>Name</label>
                    </td>
                    <td>
                        <input type="text" name="adminName" placeholder="Enter Admin Name..." class="medium" />
                    </td>
                </tr>
				<tr>
                    <td>
                        <label>Category</label>
                    </td>
                    <td>
                        <select id="select" name="categoryId">
                            <option>Select Category</option>
                            <?php 
                                $cat    = new Catagory();
                                $getCat = $cat->getAllCat();
                                if ($getCat) {
                                    while ($result = $getCat->fetch_assoc()) {
                             ?>
                            <option value="<?php echo $result['catId']; ?>"><?php echo $result['catName']; ?></option>
                            <?php } } ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>Company</label>
                    </td>
                    <td>
                        <select id="select" name="companyId">
                            <option>Select Company</option>
                            <?php 
                                $com    = new Company();
                                $getCom = $com->getAllCompany();
                                if ($getCom) {
                                    while ($result = $getCom->fetch_assoc()) {
                             ?>
                            <option value="<?php echo $result['companyId']; ?>"><?php echo $result['companyName'];?></option>
                            <?php } } ?>
                        </select>
                    </td>
                </tr>
                
                <tr>
                    <td>
                        <label>User Name</label>
                    </td>
                    <td>
                            <input type="text" name="adminUserName" placeholder="Enter Admin User Name..." class="medium" />
                    </td>
                </tr>

                <tr>
                    <td>
                        <label>Admin Email</label>
                    </td>
                    <td>
                            <input type="text" name="adminEmail" placeholder="Enter Email(optional)..." class="medium" />
                    </td>
                </tr>
				<tr>
                    <td>
                        <label>Password</label>
                    </td>
                    <td>
                        <input type="password" name="adminPass" placeholder="Password" class="medium" />
                    </td>
                </tr>
            
              
				
				<tr>
                    <td></td>
                    <td>
                        <input type="submit" name="submit" Value="Save" />
                    </td>
                </tr>
            </table>
            </form>
        </div>
    </div>
</div>
<!-- Load TinyMCE -->
<script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function () {
        setupTinyMCE();
        setDatePicker('date-picker');
        $('input[type="checkbox"]').fancybutton();
        $('input[type="radio"]').fancybutton();
    });
</script>
<!-- Load TinyMCE -->
<?php include 'inc/footer.php';?>


