<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php include '../classes/catagory.php';?>
<?php include '../classes/company.php';?>
<?php 
   $com = new Company();

   if (isset($_GET['delcompany'])) {
   	$id     = $_GET['delcompany'];
   	$delCom = $com->delComById($id);
   }
?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Category List</h2>
                <div class="block">   
                <?php 
                	if (isset($delCom)) {
                		echo $delCom;
                	}
                 ?>     
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Category Name</th>
							<th>Company Name</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$getCom = $com->getAllCompany();
							if ($getCom) {
								$i = 0;
								while ( $result = $getCom->fetch_assoc()) {
									$i++;
					      ?>						
							<tr class="odd gradeX">
								<td><?php echo $i; ?></td>
								<td><?php echo $result['catName']; ?></td>
								<td><?php echo $result['companyName']; ?></td>
								<td><a href="companyedit.php?companyid=<?php echo $result['companyId']; ?>">Edit</a> || <a onclick="return confirm('Are you sure to delete!')" href="?delcompany=<?php echo $result['companyId']; ?>">Delete</a></td>
							</tr>
						<?php } } ?>

						</tbody>
				</table>
               </div>
            </div>
        </div>
<script type="text/javascript">
	$(document).ready(function () {
	    setupLeftMenu();

	    $('.datatable').dataTable();
	    setSidebarHeight();
	});
</script>
<?php include 'inc/footer.php';?>

