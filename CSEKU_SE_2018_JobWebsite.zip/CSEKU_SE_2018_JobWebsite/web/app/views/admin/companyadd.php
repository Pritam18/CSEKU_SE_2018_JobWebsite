<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php include '../classes/company.php';?>
<?php include '../classes/catagory.php';?>

   <?php
         $com = new Company();
         if ($_SERVER['REQUEST_METHOD'] == 'POST') {
         //$comName = $_POST['comName'];

         $insertcompany = $com->companyInsert($_POST);
    }
   ?>
    <div class="grid_10">
        <div class="box round first grid">
            <h2>Add New Company</h2>
           <div class="block copyblock"> 
               <?php 
                    if (isset($insertcompany)) {
                       echo $insertcompany;
                    }
                ?>
                <form action="companyadd.php" method="POST">
                    <table class="form">
                        <tr>
                            <td>
                                <label>Category</label>
                            </td>
                            <td>
                                <select id="select" name="catId">
                                    <option>Select Category</option>
                                    <?php 
                                        $cat    = new Catagory();
                                        $getCat = $cat->getAllCat();
                                        if ($getCat) {
                                            while ($result = $getCat->fetch_assoc()) {
                                     ?>
                                    <option value="<?php echo $result['catId']; ?>"><?php echo $result['catName']; ?></option>
                                    <?php } } ?>
                                </select>
                            </td>
                        </tr>					
                        <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input type="text" name="comName" placeholder="Enter Company Name..." class="medium" />
                            </td>
                        </tr>
        				<tr> 
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>
<?php include 'inc/footer.php';?>