<?php include '../classes/adminLogin.php';?>
<?php 
$id=Session::get("adminId");
//echo $id;
    $al = new Adminlogin();
    $getLevel = $al->getAllAdminLevel($id);
    if ($getLevel) {      
        while ( $result = $getLevel->fetch_assoc()) {
        

  ?>
<div class="grid_2">
    <div class="box sidemenu">
        <div class="block" id="section-menu">
            <ul class="section menu">
                <?php 
                    if ($result['level'] == '0') {
                 ?>
                <li><a class="menuitem">Category Option</a>
                    <ul class="submenu">
                        <li><a href="catagoryadd.php">Add Category</a> </li>
                        <li><a href="catlist.php">Category List</a> </li>
                    </ul>
                </li>
               
                 <li><a class="menuitem">Company Option</a>
                    <ul class="submenu">
                        <li><a href="companyadd.php">Add Company</a> </li>
                        <li><a href="companylist.php">Company List</a> </li>
                    </ul>
                </li>
                <li><a class="menuitem">User Option</a>
                    <ul class="submenu">
                        <li><a href="userdelete.php">User List</a> </li>
                        
                    </ul>
                </li>
                 <li><a class="menuitem">Admin Option</a>
                    <ul class="submenu">
                        <li><a href="addadmin.php">Add Admin</a> </li>
                        <li><a href="adminlist.php">Admin List</a> </li>
                    </ul>
                </li>
                <?php } else { ?>
                 <li><a class="menuitem">Job Post Option</a>
                    <ul class="submenu">
                        <li><a href="addjobpost.php">Add Job</a> </li>
                        <li><a href="joblist.php">Job List</a> </li>
                    </ul>
                </li>
                 <li><a class="menuitem">Application Option</a>
                    <ul class="submenu">
                        <li><a href="applicationshow.php">Show Application</a> </li>
                        
                    </ul>
                </li>
                <?php } ?>
            </ul>
        </div>
    </div>
</div>
<?php } } ?>