<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>
<?php include '../classes/catagory.php';?>
<?php include '../classes/company.php';?>
<?php include '../classes/jobdetails.php';?>
<?php 
   $com = new Company();
   $jobdet = new Jobdetails();
   $adId = Session::get("adminId");

   if (isset($_GET['deljob'])) {
   	$id     = $_GET['deljob'];
   	$delJob = $jobdet->delJobById($id);
   }

  else if (isset($_GET['pubid'])) {
   	$pubid     = $_GET['pubid'];
   	$pubcom = $jobdet->pubById($pubid);

   }

   else if (isset($_GET['unpubid'])) {
   	$unpubid     = $_GET['unpubid'];
   	$unpubcom = $jobdet->unpubById($unpubid);
   }
?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Job List</h2>
                <div class="block">   
                <?php 
                	if (isset($delJob)) {
                		echo $delJob;
                	}
                 ?>     
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Designation</th>
							<th>Location</th>
							<th>Experience</th>
							<th>Salary</th>
							<th>Post</th>
							<th>Dead line</th>
							<th>Action</th>
							<th>Status</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$getjob = $jobdet->getAllJob($adId);
							if ($getjob) {
								$i = 0;
								while ( $result = $getjob->fetch_assoc()) {
									$i++;
					      ?>						
							<tr class="odd gradeX">
								<td><?php echo $i; ?></td>
								<td><?php echo $result['designation']; ?></td>
								<td><?php echo $result['location']; ?></td>
								<td><?php echo $result['experience']; ?></td>
								<td><?php echo $result['salary']; ?></td>
								<td><?php echo $result['apost']; ?></td>
								<td><?php echo $result['deadline']; ?></td>

								<td><a href="jobedit.php?jobid=<?php echo $result['jobid']; ?>">Edit</a> || <a onclick="return confirm('Are you sure to delete!')" href="?deljob=<?php echo $result['jobid']; ?>">Delete</a> ||<a href="?pubid=<?php echo $result['jobid']; ?>">Publish</a>|| <a href="?unpubid=<?php echo $result['jobid']; ?>">Unpublish</a></td>
								<?php
								    if($result['publish']==3)
								    {

								?>
								<td><?php echo 'Publish' ?></td>
								<?php } else { ?>
								<td><?php echo 'UnPublish' ?></td>
								<?php } ?>
							</tr>

								
						<?php } } ?>

						
							
						</tbody>
				</table>
               </div>
            </div>
        </div>
<script type="text/javascript">
	$(document).ready(function () {
	    setupLeftMenu();

	    $('.datatable').dataTable();
	    setSidebarHeight();
	});
</script>
<script>
	function myFunction() {
    document.getElementById("publish").style.color = "green";
}
</script>
<?php include 'inc/footer.php';?>

