<?php
    $filepath=realpath(dirname(__FILE__));

    include_once ($filepath.'/../lib/database.php');
    include_once ($filepath.'/../helpers/format.php');
       // include '../lib/Session.php';
      

?>
<?php
    class Jobdetails
    {
    	private $db;
    	private $fm;

    	public function __construct()
    	{
    		$this->db=new Database();
    		$this->fm=new Format();
    	}

    	public function addjob($data,$file,$companyId,$catId)
    	{
            $adminId   = Session::get("adminId");
    		
    		$designationname = $data['designationyname'];
            $location        = $data['location'];
            $experience      = $data['experience'];
            $salary          = $data['salary'];
            $apost           = $data['apost'];
    		$body            = strip_tags($data['body']);
    		$type            = $data['type'];
            $deadline        = $data['deadline'];
           
    		
    		$designationname = $this->fm->validation($designationname);
            $location        = $this->fm->validation($location);
            $experience      = $this->fm->validation($experience);
            $salary          = $this->fm->validation($salary);
            $apost           = $this->fm->validation($apost);
    		$body            = $this->fm->textShorten($body);
    		$type            = $this->fm->validation($type);
            $deadline        = $this->fm->validation($deadline);

    		
    		$designationname = mysqli_real_escape_string($this->db->link,$designationname);
            $location        = mysqli_real_escape_string($this->db->link,$location);
            $experience      = mysqli_real_escape_string($this->db->link,$experience);
            $salary          = mysqli_real_escape_string($this->db->link,$salary);
            $apost           = mysqli_real_escape_string($this->db->link,$apost);
    		$body            = mysqli_real_escape_string($this->db->link,$body);
    		$type            = mysqli_real_escape_string($this->db->link,$type);
            $deadline        = mysqli_real_escape_string($this->db->link,$deadline);

    		$permitted=array('jpeg','gif','jpg','png');
    		$file_name=$file['image']['name'];
    		$file_size=$file['image']['size'];
    		$file_temp=$file['image']['tmp_name'];

    		$div=explode('.',$file_name);
    		$file_ext=strtolower(end($div));
    		$unique_image=substr(md5(time()),0,10).'.'.$file_ext;
    		$uploaded_image="upload/".$unique_image;

    		if($designationname==""||$location==""||$experience==""||$salary==""||$apost==""||$body==""||$type==""|| $deadline == "")
    		{
    			$msg="<span class='error'>Fields Must not be empty</span>";
    			return $msg;
    		}
            else if($file_size>1048567)
            {
                echo "<span class='error'>Image must less than 1 MB</span>";
            }
            else if(in_array($file_ext, $permitted)==false)
            {
                echo "<span class='error'>You can upload only :-".implode(',', $permitted)."</span>";
            }
    		else
    		{
    			move_uploaded_file($file_temp, $uploaded_image);
    			$query="INSERT INTO tbl_companydetails(adminId,companyId,categoryId,designation,body,image,type,location,experience,salary,apost,deadline) VALUES('$adminId','$companyId','$catId','$designationname','$body','$uploaded_image','$type','$location','$experience','$salary','$apost','$deadline')";    			
    			$result=$this->db->insert($query);
    			if($result!=false)
    			{
    				$msg="<span class='success'>Data Inserted Successfully</span>";
    				return $msg;
    			}
    			else
    			{
    				$msg="<span class='errror'>Data not Inserted Successfully</span>";
    				return $msg;
    			}
    		}

    	}


// Try BY ME TRY BY ME TRY BY ME TRY BY ME TRY BY ME TRY BY ME 
        public function get_all_rows_in_companydetails()
        {
            $query="SELECT COUNT(jobid) from tbl_companydetails WHERE publish=3" ;
            $result=$this->db->select($query);
            return $result;
        }

    	public function getallcompanydetails()
    	{
    		$query="SELECT cd.*,com.companyName 
    		FROM tbl_companydetails as cd,tbl_company as com WHERE cd.companyId = com.companyId and cd.publish=3 ORDER BY jobid DESC LIMIT 2" ;
    		$result=$this->db->select($query);
    		return $result;
    	}
    	public function getallcompanydetails1()
    	{
    		$query="SELECT cd.*,com.companyName 
            FROM tbl_companydetails as cd,tbl_company as com WHERE cd.companyId = com.companyId and cd.publish=3 ORDER BY jobid ASC LIMIT 2";
            $result=$this->db->select($query);
            return $result;
    	}

        public function getallcompanydetails2()
        {
            $query="SELECT cd.*,com.companyName 
            FROM tbl_companydetails as cd,tbl_company as com WHERE cd.companyId = com.companyId and cd.publish=3 ";
            $result=$this->db->select($query);
            return $result;
        }
        public function jobdetails($id)
        {
            $query="SELECT cd.*,com.companyName,cat.catName 
            FROM tbl_companydetails as cd,tbl_company as com,tbl_category as cat WHERE  cd.jobid='$id' AND cd.companyId=com.companyId AND com.categoryId = cat.catId";
            $result=$this->db->select($query);
            return $result;
        }

        public function getAlljobFromIndex()
        {
            $query="SELECT cd.*,com.companyName 
            FROM tbl_companydetails as cd,tbl_company as com WHERE cd.companyId = com.companyId AND cd.publish=3";
            $result=$this->db->select($query);
            return $result;
        }

        public function gethotcom()
        {
            $query="SELECT cd.*,com.companyName 
            FROM tbl_companydetails as cd,tbl_company as com WHERE cd.type='1' and cd.companyId = com.companyId and cd.publish=3 ORDER BY companyId DESC LIMIT 4";
            $result=$this->db->select($query);
            return $result;
        }
        public function getnewcom()
        {
             $query="SELECT cd.*,com.companyName 
            FROM tbl_companydetails as cd,tbl_company as com WHERE cd.type='0' and cd.companyId = com.companyId and cd.publish=3 ORDER BY companyId DESC LIMIT 4";
            $result=$this->db->select($query);
            return $result;
        }
        public function getAllJob($adId)
        {
            $query="SELECT * FROM tbl_companydetails WHERE  adminId = '$adId' ";
            $result=$this->db->select($query);
            return $result;
        }
        public function getJobById($id){
            $query="SELECT * FROM tbl_companydetails WHERE  jobid = '$id' ";
            $result=$this->db->select($query);
            return $result;
        }




        
        public function pubById($id)
        {
             $query="SELECT publish FROM tbl_companydetails WHERE  jobid = '$id' ";
             $result=$this->db->select($query);
             $res = $result->fetch_assoc();
             $updateresult=$res['publish'];
             $re= $updateresult-1;

            $query1= "UPDATE tbl_companydetails
                              SET 
                              
                              publish    = '$re'
                              WHERE jobid = '$id' ";

            $updated_row = $this->db->update($query1);


        }

       public function unpubById($id)
        {
             $query="SELECT publish FROM tbl_companydetails WHERE  jobid = '$id' ";
             $result=$this->db->select($query);
             $res = $result->fetch_assoc();
             $updateresult=$res['publish'];
             $re= $updateresult+1;

            $query1= "UPDATE tbl_companydetails
                              SET 
                              
                              publish    = '$re'
                              WHERE jobid = '$id' ";

            $updated_row = $this->db->update($query1);


        }




        public function jobUpdate($data,$id)
        {

            $designationname = mysqli_real_escape_string($this->db->link, $data['designationname']);
            $location        = mysqli_real_escape_string($this->db->link, $data['location']);
            $experience      = mysqli_real_escape_string($this->db->link, $data['experience']);
            $salary          = mysqli_real_escape_string($this->db->link, $data['salary']);
            $apost           = mysqli_real_escape_string($this->db->link, $data['apost']);
            $body            = mysqli_real_escape_string($this->db->link, $data['body']);
            $type            = mysqli_real_escape_string($this->db->link, $data['type']);
            $deadline        = mysqli_real_escape_string($this->db->link, $data['deadline']);

            if ($designationname == "" || $location == "" || $experience == "" || $salary == "" || $apost == "" || 
                $body == "" || $type == "" || $deadline == "") {
                $msg = "<span class='error'> Field must not be empty !</span>";
                return $msg;
            }
            else{
                    $query = "UPDATE tbl_companydetails
                              SET 
                              designation = '$designationname',
                              body        = '$body',
                              type        = '$type',
                              location    = '$location',
                              experience  = '$experience',
                              salary      = '$salary',
                              apost       = '$apost',
                              deadline    = '$deadline'
                              WHERE jobid = '$id' ";
                    $updated_row = $this->db->update($query);
                    if ($updated_row) {
                        $msg = "<span class='success'> Updated Successfully.</span>";
                        return $msg;
                    }
                    else
                    {
                        $msg = "<span class='error'> not Updated.</span>";
                        return $msg;
                    }
            }
         }

         public function delJobById($id){

                $id      = mysqli_real_escape_string($this->db->link,$id);
                $query   = "DELETE FROM tbl_companydetails WHERE jobid ='$id'";
                $deldata = $this->db->delete($query);
                if ($deldata) 
                {
                    $msg = "<span class='success'>Job Delete Successfully.</span>";
                    return $msg;
                }
                else
                {
                        $msg = "<span class='error'>Job not Deleted.</span>";
                        return $msg;
                }
         }

         public function contact($data)
         {
            $name         = mysqli_real_escape_string($this->db->link, $data['name']);
            $email        = mysqli_real_escape_string($this->db->link, $data['Email']);
            $mobile_no    = mysqli_real_escape_string($this->db->link, $data['mobile_no']);
            $subject      = mysqli_real_escape_string($this->db->link, $data['subject']);
            $date_time    = mysqli_real_escape_string($this->db->link, $data['date_time']);
            

            if ($name == "" || $email == "" || $mobile_no == "" || $subject == "" ) {
                $msg = "<span class='error'> Field must not be empty !</span>";
                return $msg;
            }
            else{
                    $query = "INSERT into tbl_contact(name, Email, mobile_no, subject, date_time) VALUES ('$name','$email','$mobile_no','$subject','$date_time')";
                    $updated_row = $this->db->insert($query);
                    if ($updated_row) {
                        $msg = "<span class='success'> Updated Successfully.</span>";
                        return $msg;
                    }
                    else
                    {
                        $msg = "<span class='error'> not Updated.</span>";
                        return $msg;
                    }

         }

    }

     public function getAllUser()
        {
            $query="SELECT * FROM tbl_user";
            $result=$this->db->select($query);
            return $result;
        }

         public function deluserById($id){

                $id      = mysqli_real_escape_string($this->db->link,$id);
                $query   = "DELETE FROM tbl_user WHERE id ='$id'";
                $deldata = $this->db->delete($query);
                if ($deldata) 
                {
                    $msg = "<span class='success'>User Delete Successfully.</span>";
                    return $msg;
                }
                else
                {
                        $msg = "<span class='error'>User not Deleted.</span>";
                        return $msg;
                }
         }
}
?>