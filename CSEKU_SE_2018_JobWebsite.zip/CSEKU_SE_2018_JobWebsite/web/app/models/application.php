<?php
    $filepath=realpath(dirname(__FILE__));

    include_once ($filepath.'/../lib/database.php');
    include_once ($filepath.'/../helpers/format.php');
   // include_once ($filepath.'/../lib/Session.php');

?>
<?php
    class Application
    {
    	private $db;
    	private $fm;

    	public function __construct()
    	{
    		$this->db=new Database();
    		$this->fm=new Format();
    	}

    	public function adduserinformation($data)
    	{
            $appplicantid = Session::get("id");

            //$applicantid    = $appid;
    		$firstname      = $data['firstname'];
    		$lastname       = $data['lastname'];
    		$fathername     = $data['fathername'];
    		$mothername     = $data['mothername'];
    		$gender         = $data['gender'];
    		$religion       = $data['religion'];
    		$marital_status = $data['mstatus'];
    		$nationality    = $data['country'];
    		$nationalid     = $data['nId'];
    		$address        = $data['address'];
    		$paddress       = $data['paddress'];
    		//$phoneno1       = $data['phonnum1'];
    		//$phoneno2       = $data['phonnum2'];
    		$email          = $data['email'];
    	
    		//$applicantid    = $this->fm->validation($applicantid);
    		$firstname      = $this->fm->validation($firstname);
    		$lastname       = $this->fm->validation($lastname);
    		$fathername     = $this->fm->validation($fathername);
    		$mothername     = $this->fm->validation($mothername);
    		$gender         = $this->fm->validation($gender);
    		$religion       = $this->fm->validation($religion);
    		$marital_status = $this->fm->validation($marital_status);
    		$nationality    = $this->fm->validation($nationality);
            $nationalid     = $this->fm->validation($nationalid);
    		$address        = $this->fm->validation($address);
    		$paddress       = $this->fm->validation($paddress);
    		//$phoneno1       = $this->fm->validation($phoneno1);
    		//$phoneno2       = $this->fm->validation($phoneno2);
    		$email          = $this->fm->validation($email);

            $firstname      = mysqli_real_escape_string($this->db->link,$firstname);
            $lastname       = mysqli_real_escape_string($this->db->link,$lastname);
            $fathername     = mysqli_real_escape_string($this->db->link,$fathername);
            $mothername     = mysqli_real_escape_string($this->db->link,$mothername);
            $gender         = mysqli_real_escape_string($this->db->link,$gender);
            $religion       = mysqli_real_escape_string($this->db->link,$religion);
            $marital_status = mysqli_real_escape_string($this->db->link,$marital_status);
            $nationality    = mysqli_real_escape_string($this->db->link,$nationality);
            $nationalid     = mysqli_real_escape_string($this->db->link,$nationalid);
            $address        = mysqli_real_escape_string($this->db->link,$address);
            $paddress       = mysqli_real_escape_string($this->db->link,$paddress);
            //$phoneno1       = mysqli_real_escape_string($this->db->link,$phoneno1);
            //$phoneno2       = mysqli_real_escape_string($this->db->link,$phoneno2);
            $email          = mysqli_real_escape_string($this->db->link,$email);

    		$check_email=$this->checkemail($email);         

    		if($firstname == "" || $lastname== ""|| $email == "")
    		{
    			$msg="<span class='error'>Fields Must not be empty</span>";
    			return $msg;
    		}
            if(filter_var($email,FILTER_VALIDATE_EMAIL)===false)
            {
                $msg="<div class='alert alert-danger'><strong>Error ! </strong>Email is invalid</div>";
                return $msg;
            } 
            if($check_email==true)
            {
              $msg="<div class='alert alert-danger'><strong>Error ! </strong>Email is already existing</div>";
              return $msg;
            }
           else
    		{
                $query="INSERT INTO tbl_application(appplicantid,fname,lname,faname,moname,gender,religion,marital_status,nationality,nationalid,presentaddress,permanentaddress,email) VALUES('$appplicantid','$firstname','$lastname','$fathername','$mothername','$gender','$religion','$marital_status','$nationality','$nationalid','$address','$paddress','$email')";

    			$result=$this->db->insert($query);
    			if($result!=false)
    			{
    				$msg="<span class='success'>Data Inserted Successfully</span>";
    				return $msg;
    			}
    			else
    			{
    				$msg="<span class='errror'>Data not Inserted Successfully</span>";
    				return $msg;
    			}
            }
    	}
            
        public function checkemail($email)
        {
        $query="SELECT email FROM tbl_application WHERE email='$email' ";
        $result=$this->db->select($query);
        if($result)
           return true;
       else
           return false;
        }


        public function getinformation($id)
        {
        $query="SELECT appplicantid FROM tbl_application WHERE appplicantid='$id' ";
        $result=$this->db->select($query);
        if($result)
           return true;
        else
           return false;
        }    		

        public function getallinformation($id)
        {
        $query  = "SELECT * FROM tbl_application WHERE appplicantid='$id' ";
        $result = $this->db->select($query);
        return $result;
        }  

        public function insertapplication($jobid,$cid,$id,$aplid)
        {

        $query  = "INSERT INTO tbl_apply(JobId,CompanyId,ApplicantId,AdminId) VALUES('$jobid','$cid','$id','$aplid')";

        $result = $this->db->insert($query);
        if($result)
            return true;
         else
            return false;
         } 

         public function getAllApplication($adId){
            
             $query   = "SELECT distinct apl.*,comd.designation FROM tbl_application as apl, tbl_apply as ap, tbl_companydetails as comd WHERE apl.appplicantid = ap.ApplicantId AND ap.AdminId = '$adId' AND ap.AdminId = comd.adminId ";
             $result = $this->db->select($query);
             return $result;
         }     


         public function updateuserinformation($data,$id)
        {
            $appplicantid = Session::get("id");

            //$applicantid    = $appid;
            $firstname      = $data['fname'];
            $lastname       = $data['lname'];
            $fathername     = $data['faname'];
            $mothername     = $data['moname'];
            $gender         = $data['gender'];
            $religion       = $data['religion'];
            $marital_status = $data['marital_status'];
            $nationality    = $data['nationality'];
            
            $address        = $data['presentaddress'];
            $paddress       = $data['permanentaddress'];
            //$phoneno1       = $data['phonnum1'];
            //$phoneno2       = $data['phonnum2'];
            $email          = $data['email'];
        
            //$applicantid    = $this->fm->validation($applicantid);
            $firstname      = $this->fm->validation($firstname);
            $lastname       = $this->fm->validation($lastname);
            $fathername     = $this->fm->validation($fathername);
            $mothername     = $this->fm->validation($mothername);
            $gender         = $this->fm->validation($gender);
            $religion       = $this->fm->validation($religion);
            $marital_status = $this->fm->validation($marital_status);
            $nationality    = $this->fm->validation($nationality);
            $nationalid     = $this->fm->validation($nationalid);
            $address        = $this->fm->validation($address);
            $paddress       = $this->fm->validation($paddress);
            //$phoneno1       = $this->fm->validation($phoneno1);
            //$phoneno2       = $this->fm->validation($phoneno2);
            $email          = $this->fm->validation($email);

            $firstname      = mysqli_real_escape_string($this->db->link,$firstname);
            $lastname       = mysqli_real_escape_string($this->db->link,$lastname);
            $fathername     = mysqli_real_escape_string($this->db->link,$fathername);
            $mothername     = mysqli_real_escape_string($this->db->link,$mothername);
            $gender         = mysqli_real_escape_string($this->db->link,$gender);
            $religion       = mysqli_real_escape_string($this->db->link,$religion);
            $marital_status = mysqli_real_escape_string($this->db->link,$marital_status);
            $nationality    = mysqli_real_escape_string($this->db->link,$nationality);
            $nationalid     = mysqli_real_escape_string($this->db->link,$nationalid);
            $address        = mysqli_real_escape_string($this->db->link,$address);
            $paddress       = mysqli_real_escape_string($this->db->link,$paddress);
            //$phoneno1       = mysqli_real_escape_string($this->db->link,$phoneno1);
            //$phoneno2       = mysqli_real_escape_string($this->db->link,$phoneno2);
            $email          = mysqli_real_escape_string($this->db->link,$email);

            $check_email=$this->checkemail($email);         

            if($firstname == "" || $lastname== ""|| $email == "")
            {
                $msg="<span class='error'>Fields Must not be empty</span>";
                return $msg;
            }
            if(filter_var($email,FILTER_VALIDATE_EMAIL)===false)
            {
                $msg="<div class='alert alert-danger'><strong>Error ! </strong>Email is invalid</div>";
                return $msg;
            } 
            if($check_email==true)
            {
              $msg="<div class='alert alert-danger'><strong>Error ! </strong>Email is already existing</div>";
              return $msg;
            }
           else
            {
                $query="INSERT INTO tbl_application(appplicantid,fname,lname,faname,moname,gender,religion,marital_status,nationality,nationalid,presentaddress,permanentaddress,email) VALUES('$appplicantid','$firstname','$lastname','$fathername','$mothername','$gender','$religion','$marital_status','$nationality','$nationalid','$address','$paddress','$email')";
                $query="UPDATE tbl_application SET applicantid='$id',
                                                    fname='$firstname',
                                                    lname='$lastname',
                                                    faname='$fathername',
                                                    moname='$mothername',
                                                    gender='$gender',
                                                    religion='$religion',
                                                    marital_status='$marital_status',
                                                    nationality='$nationality',
                                                    presentaddress='$address',
                                                    permanentaddress='$paddress',
                                                    email='$email' WHERE applicatid='$id'";

                $result=$this->db->update($query);
                if($result!=false)
                {
                    $msg="<span class='success'>Data updated Successfully</span>";
                    return $msg;
                }
                else
                {
                    $msg="<span class='errror'>Data not updated Successfully</span>";
                    return $msg;
                }
            }
        }    

    }   	
?>