<?php 
	$filepath = realpath(dirname(__FILE__));
	//include_once ($filepath.'/../lib/Session.php');
	//include '../lib/Session.php';
	//Session::checkLogin(); 
	include_once ($filepath.'/../lib/Database.php');
	include_once ($filepath.'/../helpers/Format.php');	
 ?>

<?php 
	class Adminlogin
	{
		private $db;
		private $fm;

		public function __construct()
		{
			$this->db = new Database();
			$this->fm = new Format();
		}

		public function adminLogin($adminUserName,$adminPass)
		{
			$adminUserName = $this->fm->validation($adminUserName);
			$adminPass     = $this->fm->validation($adminPass);

			$adminUserName = mysqli_real_escape_string($this->db->link,$adminUserName);
			$adminPass     = mysqli_real_escape_string($this->db->link,$adminPass);

			if (empty($adminUserName) || empty($adminPass)) {
				$loginmsg = "Username or Password must not be empty !";
				return $loginmsg;  
			} else{
				$query = "SELECT * FROM tbl_admin WHERE  adminUserName = '$adminUserName' AND adminPass='$adminPass'";
				$result = $this->db->select($query);
				if ($result != false) {
					$value = $result->fetch_assoc();
					Session::set("adminlogin",true);
					Session::set("adminId", $value['adminId']);
                    Session::set("companyId", $value['companyId']);                  
                    Session::set("categoryId", $value['categoryId']);
					Session::set("adminUserName", $value['adminUserName']);
					Session::set("adminName", $value['adminName']);
					header("Location:dashboard.php");
				}
				else{
					$loginmsg = "Username or Password  not match !";
					return $loginmsg;
				}
			}


		}

		public function adminAdd($data)
        {          
            $adminName     = mysqli_real_escape_string($this->db->link, $data['adminName']);
            $categoryId    = mysqli_real_escape_string($this->db->link, $data['categoryId']);
            $companyId     = mysqli_real_escape_string($this->db->link, $data['companyId']);
            $adminUserName = mysqli_real_escape_string($this->db->link, $data['adminUserName']);
            $adminEmail    = mysqli_real_escape_string($this->db->link, $data['adminEmail']);
            $adminPass     = mysqli_real_escape_string($this->db->link, md5($data['adminPass']));
           // $level         = mysqli_real_escape_string($this->db->link, $data['level']);
            
            
            if (filter_var($adminEmail,FILTER_VALIDATE_EMAIL) === false)
            {
                $msg="<span class='error'><strong>Error ! </strong>Email is invalid</span>";
                return $msg;
            }
          
            if (empty($adminUserName) || empty($adminPass)) 
            {
                $msg = "<span class='error'>Admin Field must not be empty !</span>";
                return $msg;  
            }
            else
            {
                    $query = "INSERT INTO tbl_admin(adminName,categoryId,companyId,adminUserName,
                    adminEmail,adminPass,level) VALUES('$adminName','$categoryId','$companyId','$adminUserName','$adminEmail','$adminPass','1')";
                    $admininsert = $this->db->insert($query);
                    if ($admininsert) {
                        $msg = "<span class='success'>Admin Inserted Successfully.</span>";
                        return $msg;
                    }
                    else
                    {
                        $msg = "<span class='error'>Admin not Inserted.</span>";
                        return $msg;
                    }
                }
        }

        public function getAllAdmin()
        {
        	 $query = "SELECT a.*,c.catName,com.companyName
                      FROM tbl_admin as a,tbl_company as com, tbl_category as c
                      WHERE a.categoryId = c.catId and a.companyId = com.companyId and a.level='1' 
                      ORDER BY a.adminName DESC";

            $result= $this->db->select($query);
            return $result;
        }
        public function delAdminById($id)
        {
        	$id     = mysqli_real_escape_string($this->db->link,$id);
            $query  = "DELETE FROM tbl_admin WHERE adminId ='$id'";
            $deldata= $this->db->delete($query);
            if ($deldata) {
                $msg = "<span class='success'>Admin Delete Successfully.</span>";
                return $msg;
            }else{
                    $msg = "<span class='error'>Admin not Deleted.</span>";
                    return $msg;
                }
        }
        public function getAllAdminLevel($id){
        	$query  = "SELECT level FROM tbl_admin where adminId=$id ";
            $result = $this->db->select($query);
            return $result;
        }

        public function changepassword($data)
        {
            $userName    = mysqli_real_escape_string($this->db->link, $data['userName']);
            $oldpassword = mysqli_real_escape_string($this->db->link, md5($data['opass']));
            $newpassword = mysqli_real_escape_string($this->db->link, md5($data['npass']));
            if ($userName==""||$oldpassword==""||$newpassword=="") {
                $loginmsg = "Username or Password must not be empty !";
                return $loginmsg;  
            }
            else
            {
                $query="UPDATE tbl_admin SET adminPass='$newpassword' WHERE adminUserName='$userName' and adminPass='$oldpassword'";
                $updatepass= $this->db->update($query);
                if ($updatepass) 
                {
                     $msg = "<span class='success'>Admin Password Updated Successfully.</span>";
                     return $msg;
                } 
                else
                {
                    $msg = "<span class='error'>Admin Password not Updated Successfully.</span>";
                    return $msg;
                }
            }
       }
}
	
 ?>