<?php 
    $filepath = realpath(dirname(__FILE__));
    include_once ($filepath.'/../lib/Database.php');
    include_once ($filepath.'/../helpers/Format.php');  
?>
<?php 
    class Company
    {       
        private $db;
        private $fm;

        public function __construct()
        {
            $this->db = new Database(); 
            $this->fm = new Format();
        }
        public function companyInsert($data)
        {
           
            $catId   = mysqli_real_escape_string($this->db->link, $data['catId']);
            $comName = mysqli_real_escape_string($this->db->link, $data['comName']);
            
            if (empty($comName)) {
                $msg = "<span class='error'>Company Field must not be empty !</span>";
                return $msg;  
             }
             else
                {
                    $query     = "INSERT INTO tbl_company(categoryId,companyName) VALUES('$catId','$comName')";
                    $cominsert = $this->db->insert($query);
                    if ($cominsert) {
                        $msg = "<span class='success'>Company Inserted Successfully.</span>";
                        return $msg;
                    }
                    else
                    {
                        $msg = "<span class='error'>Company not Inserted.</span>";
                        return $msg;
                    }
                }
        }

        public function getAllCompany()
        {
            $query = "SELECT com.*, c.catName
                      FROM tbl_company as com, tbl_category as c
                      WHERE com.categoryId = c.catId 
                      ORDER BY com.companyId DESC";

            $result= $this->db->select($query);
            return $result;
        }
        public function getComById($id)
        {
            $query  = "SELECT * FROM tbl_company WHERE companyId ='$id'";
            $result = $this->db->select($query);
            return $result;
        }
        public function companyUpdate($comName,$id)
        {
            $comName = $this->fm->validation($comName);
            $comName = mysqli_real_escape_string($this->db->link,$comName);
            $id      = mysqli_real_escape_string($this->db->link,$id);
            if (empty($comName)) {
                $msg = "<span class='error'>Company Field must not be empty !</span>";
                return $msg;  
            }
            else
            {
                $query       = "UPDATE tbl_company SET  companyName = '$comName' WHERE companyId = '$id'";
                $updated_row = $this->db->update($query);
            
                if ($updated_row) {
                    $msg = "<span class='success'>Company Updated Successfully.</span>";
                    return $msg;
                }else{
                    $msg = "<span class='error'>Company not Updated.</span>";
                    return $msg;
                }
            } 
        }
       public function delComById($id){
            $id     = mysqli_real_escape_string($this->db->link,$id);
            $query  = "DELETE FROM tbl_company WHERE companyId ='$id'";
            $deldata= $this->db->delete($query);
            if ($deldata) {
                $msg = "<span class='success'>Company Delete Successfully.</span>";
                return $msg;
            }else{
                    $msg = "<span class='error'>Company not Deleted.</span>";
                    return $msg;
                }
       }
    }

 ?>