<?php include 'inc/header.php';?>
<?php include 'inc/sidebar.php';?>

<?php include '../classes/company.php';?>
<?php //include '../classes/adminLogin.php';?>
<?php include '../classes/application.php';?>

<?php 
    $app = new Application();

   // if (isset($_GET['deladmin'])) {
   // 	$id       = $_GET['deladmin'];
   // 	$delAdmin = $al->delAdminById($id);
  // }
    $adId = Session::get("adminId");
?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Category List</h2>
                <div class="block">   
                <?php 
                	// if (isset($delAdmin)) {
                	// 	echo $delAdmin;
                	// }
                 ?>     
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Applicant Name</th>
							<th>Designation</th>
							<th>Gender</th>
							<th>Email</th>
							<th>Nationality</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							 $getApplication = $app->getAllApplication($adId);
							 if ($getApplication) {
							 	$i = 0;
							 	while ( $result = $getApplication->fetch_assoc()) {
							 		$i++;
					      ?>						
							<tr class="odd gradeX">
								<td><?php echo $i; ?></td>
								<td><?php echo $result['fname']; ?></td>
								<td><?php echo $result['designation']; ?></td>
								<td><?php echo $result['gender']; ?></td>
								<td><?php echo $result['email']; ?></td>
								<td><?php echo $result['nationality']; ?></td>
								<td><a href="#">Accept</a> || <a onclick="return confirm('Are you sure to delete!')" href="#">Reject</a></td>
							</tr>
						<?php } } ?>

						</tbody>
				</table>
               </div>
            </div>
        </div>
<script type="text/javascript">
	$(document).ready(function () {
	    setupLeftMenu();

	    $('.datatable').dataTable();
	    setSidebarHeight();
	});
</script>
<?php include 'inc/footer.php';?>

